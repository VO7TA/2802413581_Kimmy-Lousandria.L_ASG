#include <stdio.h>
#include <string.h>

#define MAX_MEDICINES 4

typedef struct {
    char code[7];
    char name[50];
    char disease[50];
    int stock;
    int price;
} Medicine;

Medicine medicines[MAX_MEDICINES] = {
    {"DIZ001", "Paramex", "Dizzines", 120, 14000},
    {"FLU001", "Panadol", "Flu & Fever", 57, 8000},
    {"DIA001", "Diatabs", "Diarrhea", 10, 6500},
    {"DIA002", "Diapet", "Diarrhea", 18, 6000},
};

void displayMedicines() {
    printf("                                         +------------------+                                   \n");
    printf("                                         |  SUNIB Hospital  |                                   \n");
    printf("                                         +------------------+                                   \n");
    printf("+------------------------------------------------------------------------------------------------+");
    printf("\n|%-5s| %-20s| %-20s| %-15s| %-10s| %-15s |\n", "No", "Medicine Code", "Medicine Name", "Disease", "Stock", "Price");
    printf("|------------------------------------------------------------------------------------------------|\n");
    for (int i = 0; i < MAX_MEDICINES; i++) {
        printf("|%-5d| %-20s| %-20s| %-15s| %-10d| Rp %-10d,-|\n", i + 1, medicines[i].code, medicines[i].name, medicines[i].disease, medicines[i].stock, medicines[i].price);
    }
    printf("+------------------------------------------------------------------------------------------------+\n");
}

int findMedicine(char *code) {
    for (int i = 0; i < MAX_MEDICINES; i++) {
        if (strcmp(medicines[i].code, code) == 0) {
            return i;
        }
    }
    return -1;
}

void addStock() {
    char code[7];
    int quantity, index;
    
    do {
        printf("\nEnter medicine code to add stock: ");
        scanf("%6s", code);
        index = findMedicine(code);
        if (index == -1) {
            printf("Medicine Code Doesn't Exist!\n");
        }
    } while (index == -1);
    
    do {
        printf("Enter quantity (1-100): ");
        scanf("%d", &quantity);
        if (quantity < 1 || quantity > 100) {
            printf("Invalid quantity! Must be between 1 and 100.\n");
        }
    } while (quantity < 1 || quantity > 100);
    
    medicines[index].stock += quantity;
    printf("Stock updated successfully. Press Enter to continue...\n");
    getchar(); getchar();
}

void sellMedicine() {
    char code[7];
    int quantity, index;
    
    do {
        printf("\nEnter medicine code to sell: ");
        scanf("%6s", code);
        index = findMedicine(code);
        if (index == -1) {
            printf("Medicine Code Doesn't Exist!\n");
        }
    } while (index == -1);
    
    do {
        printf("Enter quantity (1-%d): ", medicines[index].stock);
        scanf("%d", &quantity);
        if (quantity < 1 || quantity > medicines[index].stock) {
            printf("Invalid quantity! Must be between 1 and available stock.\n");
        }
    } while (quantity < 1 || quantity > medicines[index].stock);
    
    int totalPrice = medicines[index].price * quantity;
    medicines[index].stock -= quantity;
    printf("Total Price = Rp %d,-\n", totalPrice);
    printf("Stock updated successfully. Press Enter to continue...\n");
    getchar(); getchar();
}

int main() {
    int choice;
    do {
        displayMedicines();
        printf("\nMenu:\n");
        printf("1. Add Stock\n");
        printf("2. Sell\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1:
                addStock();
                break;
            case 2:
                sellMedicine();
                break;
            case 3:
                printf("Exiting program...\n");
                break;
            default:
                printf("Invalid choice! Try again.\n");
        }
    } while (choice != 3);
    
    return 0;
}
