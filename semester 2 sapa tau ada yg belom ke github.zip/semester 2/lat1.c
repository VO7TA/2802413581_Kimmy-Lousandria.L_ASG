#include <stdio.h> 
#include <string.h>
#include <stdlib.h>


struct mobil {
    int id;
    char merk[20];
    char type[20];
    int harga;
    int qty;
    char warna[20];
    struct mobil *next;

}*head,*tail,*curr;

int main (){
    int menu;

    do{
        view();
        puts("1.tambah data");
        puts("hapus data by Id");
        puts("3.exit");
        scanf("%d",menu);
        switch (menu){

            case 1 : tambah();
                    break;
            case 2 : hapus();
                    break;

        }
        
    }while(menu!=3);


}