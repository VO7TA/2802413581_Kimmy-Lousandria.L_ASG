#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>



int main (){
    int input;
    
    system("cls");
		printf("Menu BST (INSERT)\n");
		printf("1. View inorder\n");
		printf("2. Insert\n");
		printf("3. Exit\n");
		printf("Input >>");
		scanf("%d", &input);
		switch(input)
		{
}