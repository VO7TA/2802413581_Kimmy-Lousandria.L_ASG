#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>



typedef struct Customer {
    char phone_number[14];
    char name[26];
    char email[21];
    int points;
    struct Customer *left;
    struct Customer *right;
} Customer;


Customer *createNode(const char *phone_number, const char *name, const char *email) {
    Customer *newNode = (Customer *)malloc(sizeof(Customer));
    strcpy(newNode->phone_number, phone_number);
    strcpy(newNode->name, name);
    strcpy(newNode->email, email);
    newNode->points = 10; 
    newNode->left = newNode->right = NULL;
    return newNode;
}


Customer *insert(Customer *root, const char *phone_number, const char *name, const char *email) {
    if (root == NULL) {
        return createNode(phone_number, name, email);
    }

    if (strcmp(phone_number, root->phone_number) < 0) {
        root->left = insert(root->left, phone_number, name, email);
    } else if (strcmp(phone_number, root->phone_number) > 0) {
        root->right = insert(root->right, phone_number, name, email);
    }

    return root;
}


Customer *search(Customer *root, const char *phone_number) {
    if (root == NULL || strcmp(root->phone_number, phone_number) == 0) {
        return root;
    }

    if (strcmp(phone_number, root->phone_number) < 0) {
        return search(root->left, phone_number);
    }

    return search(root->right, phone_number);
}


Customer *deleteNode(Customer *root, const char *phone_number) {
    if (root == NULL) {
        return root;
    }

    if (strcmp(phone_number, root->phone_number) < 0) {
        root->left = deleteNode(root->left, phone_number);
    } else if (strcmp(phone_number, root->phone_number) > 0) {
        root->right = deleteNode(root->right, phone_number);
    } else {
       
        if (root->left == NULL) {
            Customer *temp = root->right;
            free(root);
            return temp;
        } else if (root->right == NULL) {
            Customer *temp = root->left;
            free(root);
            return temp;
        }

       
        Customer *temp = root->right;
        while (temp->left != NULL) {
            temp = temp->left;
        }
        strcpy(root->phone_number, temp->phone_number);
        strcpy(root->name, temp->name);
        strcpy(root->email, temp->email);
        root->points = temp->points;
        root->right = deleteNode(root->right, temp->phone_number);
    }
    return root;
}


void inOrder(Customer *root) {
    if (root != NULL) {
        inOrder(root->left);
        printf("| %-12s | %-20s | %-20s | %6d |\n",
               root->name, root->phone_number, root->email, root->points);
        inOrder(root->right);
    }
}


void deleteAll(Customer *root) {
    if (root != NULL) {
        deleteAll(root->left);
        deleteAll(root->right);
        free(root);
    }
}


bool isValidPhoneNumber(const char *phone_number) {
    int length = strlen(phone_number);
    if (length < 10 || length > 13) {
        return false;
    }
    for (int i = 0; i < length; i++) {
        if (!isdigit(phone_number[i])) {
            return false;
        }
    }
    return true;
}


bool isValidName(const char *name) {
    int length = strlen(name);
    if (length < 5 || length > 25) {
        return false;
    }
    if (strncmp(name, "Mr.", 3) != 0 && strncmp(name, "Mrs.", 4) != 0) {
        return false;
    }
    return true;
}


bool isValidEmail(const char *email) {
    int length = strlen(email);
    if (length < 10 || length > 20) {
        return false;
    }
    int at_count = 0;
    for (int i = 0; i < length; i++) {
        if (email[i] == '@') {
            at_count++;
        }
    }
    if (at_count != 1) {
        return false;
    }
    if (strstr(email, ".com") == NULL && strstr(email, ".co.id") == NULL) {
        return false;
    }
    return true;
}


void processOrder(Customer **root) {
    char phone_number[14];
    char name[26];
    char email[21];
    Customer *customer;

    while (true) {
        printf("Input phone number[10-13][numeric]: ");
        scanf("%s", phone_number);
        if (strlen(phone_number) >= 10 && strlen(phone_number) <= 13) {
            break;
        }
        printf("Invalid phone number!\n");
    }

    customer = search(*root, phone_number);

    if (customer == NULL) {
        while (true) {
            printf("Input name[5-25][Mr. ][Mrs. ];");
            scanf(" %[^\n]s", name);
            if (strncmp(name, "Mr.", 3) == 0 || strncmp(name, "Mrs.", 4) == 0) {
                break;
            }
            printf("Invalid name!\n");
        }

        while (true) {
            printf("Input email[10-20][email format]: ");
            scanf("%s", email);
            if (strstr(email, "@") != NULL && (strstr(email, ".com") != NULL || strstr(email, ".co.id") != NULL)) {
                break;
            }
            printf("Invalid email!\n");
        }

        *root = insert(*root, phone_number, name, email);
        printf("Insert success!\n");
    } else {
        printf("Welcome back, %s!\n", customer->name);
    }

    int total_price = 0;
    char order_more[2];

    
    if (customer != NULL && customer->points >= 25) {
        char use_points[2];
        printf("Do you want to use your points?[You have %d] [y/n]: ", customer->points);
        while (true) {
            scanf("%s", use_points);
            if (strcmp(use_points, "y") == 0 || strcmp(use_points, "n") == 0) {
                break;
            }
            printf("Invalid input! Please enter 'y' or 'n': ");
        }

        if (strcmp(use_points, "y") == 0) {
            int points_to_redeem;
            while (true) {
                printf("How much[%d left]: ", customer->points);
                scanf("%d", &points_to_redeem);
                if (points_to_redeem % 25 == 0 ) {
                  printf("you have %d Free drink(s)!\n",points_to_redeem / 25);break; 
					
                }else (points_to_redeem % 25 != 0 );
                	printf("You have 0 drink(s) left");break;
				
            }
            customer->points -= points_to_redeem;
            
        }
    }

    do {
        char drink_name[30];
        int drink_price = 30000;
        int drink_quantity;

        while (true) {
            printf("Input drink name (Cafe Latte, Caramel Macchiato, Cappuccino, Cafe Mocha): ");
            scanf(" %[^\n]s", drink_name);
            if (strcmp(drink_name, "Cafe Latte") == 0 || strcmp(drink_name, "Caramel Macchiato") == 0 ||
                strcmp(drink_name, "Cappuccino") == 0 || strcmp(drink_name, "Cafe Mocha") == 0) {
                break;
            }
            printf("Invalid drink name!\n");
        }

        while (true) {
            printf("Input drink quantity (at least 1): ");
            scanf("%d", &drink_quantity);
            if (drink_quantity >= 1) {
                break;
            }
            printf("Invalid quantity!\n");
        }

        total_price += drink_price * drink_quantity;

        printf("Do you want to order more? [y/n]: ");
        while (true) {
            scanf("%s", order_more);
            if (strcmp(order_more, "y") == 0 || strcmp(order_more, "n") == 0) {
                break;
            }
            printf("Invalid input! Please enter 'y' or 'n': ");
        }
    } while (strcmp(order_more, "y") == 0);

    int points_earned = total_price / 50000 * 3;
    if (customer != NULL) {
        customer->points += points_earned;
    }

    printf("\n--- Order Summary ---\n");
    printf("Total Price: %d\n", total_price);
    printf("Points Earned: %d\n", points_earned);
    printf("Total Points: %d\n", (customer != NULL) ? customer->points : 10);
    printf("----------------------\n");
}


int main() {
    Customer *root = NULL;
    int choice;

    do {
        // Tampilkan menu
        printf("\nBlueBucks\n");
        printf("1. Process Order\n");
        printf("2. View All Customer\n");
        printf("3. Remove Customer\n");
        printf("4. Exit\n");
        printf(">> ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                processOrder(&root);
                break;
            case 2:
                // Tampilkan semua pelanggan
                if (root == NULL) {
                    printf("There is no data!\n");
                } else {
                    printf("| Name         | Phone Number   | Email                | Points |\n");
                    printf("-------------------------------------------------------------\n");
                    inOrder(root);
                }
                printf("Press Enter to continue...");
                getchar();
                getchar(); // Consume newline
                break;
            case 3:
                // Hapus pelanggan
                if (root == NULL) {
                    printf("There is no data!\n");
                } else {
                    char phone_number_to_delete[14];
                    printf("Input phone number: ");
                    scanf("%s", phone_number_to_delete);
                    if (search(root, phone_number_to_delete) == NULL) {
                        printf("Data invalid!\n");
                    } else {
                        root = deleteNode(root, phone_number_to_delete);
                        printf("Delete success!\n");
                    }
                }
                printf("Press Enter to continue...");
                getchar();
                getchar(); 
                break;
            case 4:
                
                deleteAll(root);
                printf("Exiting program...\n");
                break;
            default:
                printf("Invalid choice!\n");
        }
    } while (choice != 4);

    return 0;
}
