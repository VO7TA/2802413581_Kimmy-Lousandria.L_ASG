#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct Node {
    char title[26];
    char genre[20]; 
    int stock;
    int height;
    struct Node *left, *right;
} Node;

int max(int a, int b) {
    return (a > b) ? a : b;
}

int height(Node *n) {
    return n ? n->height : 0;
}

Node* createNode(char *title, char *genre, int stock) {
    Node *newNode = (Node *)malloc(sizeof(Node));
    strcpy(newNode->title, title);
    strcpy(newNode->genre, genre);
    newNode->stock = stock;
    newNode->left = newNode->right = NULL;
    newNode->height = 1;
    return newNode;
}

int getBalance(Node *n) {
    return n ? height(n->left) - height(n->right) : 0;
}

Node *rightRotate(Node *y) {
    Node *x = y->left;
    Node *T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;
    return x;
}

Node *leftRotate(Node *x) {
    Node *y = x->right;
    Node *T2 = y->left;
    y->left = x;
    x->right = T2;
    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;
    return y;
}

Node *search(Node *root, char *title) {
    if (!root) return NULL;
    int cmp = strcmp(title, root->title);
    if (cmp < 0) return search(root->left, title);
    else if (cmp > 0) return search(root->right, title);
    else return root;
}

Node* insert(Node *root, char *title, char *genre, int stock) {
    if (!root) return createNode(title, genre, stock);
    int cmp = strcmp(title, root->title);
    if (cmp < 0) root->left = insert(root->left, title, genre, stock);
    else if (cmp > 0) root->right = insert(root->right, title, genre, stock);
    else return root; 

    root->height = 1 + max(height(root->left), height(root->right));
    int balance = getBalance(root);

  
    if (balance > 1 && strcmp(title, root->left->title) < 0) return rightRotate(root);
    if (balance < -1 && strcmp(title, root->right->title) > 0) return leftRotate(root);
    if (balance > 1 && strcmp(title, root->left->title) > 0) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    if (balance < -1 && strcmp(title, root->right->title) < 0) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}

void inOrder(Node *root) { 

    if (!root) return;
   
	inOrder(root->left);
    printf("|%-7s			| %-7s			|%-7d			|\n", root->title, root->genre, root->stock);
    inOrder(root->right);
}

Node* findMin(Node *node) {
    while (node->left) node = node->left;
    return node;
}

Node* deleteNode(Node *root, char *title) {
    if (!root) return NULL;
    int cmp = strcmp(title, root->title);
    if (cmp < 0) root->left = deleteNode(root->left, title);
    else if (cmp > 0) root->right = deleteNode(root->right, title);
    else {
        if (!root->left || !root->right) {
            Node *temp = root->left ? root->left : root->right;
            free(root);
            return temp;
        } else {
            Node *temp = findMin(root->right);
            strcpy(root->title, temp->title);
            strcpy(root->genre, temp->genre);
            root->stock = temp->stock;
            root->right = deleteNode(root->right, temp->title);
        }
    }

    root->height = 1 + max(height(root->left), height(root->right));
    int balance = getBalance(root);

    // Rotation after delete
    if (balance > 1 && getBalance(root->left) >= 0) return rightRotate(root);
    if (balance > 1 && getBalance(root->left) < 0) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    if (balance < -1 && getBalance(root->right) <= 0) return leftRotate(root);
    if (balance < -1 && getBalance(root->right) > 0) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}

void toLowerCase(char *str) {
    for (int i = 0; str[i]; i++) str[i] = tolower(str[i]);
}

int validateGenre(char *genre) {
    return strcmp(genre, "Action") == 0 ||
           strcmp(genre, "RPG") == 0 ||
           strcmp(genre, "Adventure") == 0 ||
           strcmp(genre, "Card Game") == 0;
}


int main() {
    Node *root = NULL;
    int menu;

    do {
        printf("\nBluejack GShop\n==============\n1. Insert Game\n2. View Game\n3. Update Stock\n4. Exit\n >> ");
        scanf("%d", &menu);
        getchar();

        if (menu == 1) {
            char title[26], genre[20];
            int stock; 
            

            do {
                printf("Input Game Title [5-25 chars]: ");
                fgets(title, 26, stdin);
                title[strcspn(title, "\n")] = 0;
            } while (strlen(title) < 5 || strlen(title) > 25 || search(root, title));

            do { 
            	
                printf("Input Game Genre [Action | RPG | Adventure | Card Game]: ");
                fgets(genre, 20, stdin);
                genre[strcspn(genre, "\n")] = 0;
            } while (!validateGenre(genre));

            do {
                printf("Input Game Stock [>=1]: ");
                scanf("%d", &stock);
                getchar();
            } while (stock < 1);

            root = insert(root, title, genre, stock);
        }

        else if (menu == 2) {
            if (!root) printf("Warehouse is empty !\n");
            else  
			puts("-------------------------------------------------------------------------------------------------");
    		puts("|Game Title			|Game Genre			|Game stock			|");
			inOrder(root);
        }

        else if (menu == 3) {
            char title[26];
            printf("Input Game Title: ");
            fgets(title, 26, stdin);
            title[strcspn(title, "\n")] = 0;

            Node *game = search(root, title);
            if (!game) {
                printf("Data not found\n");
                continue;
            }

            char type[10];
            int qty;
            do {
                printf("Input update type [add|remove][case sensitive]: ");
                fgets(type, 10, stdin);
                type[strcspn(type, "\n")] = 0;
                toLowerCase(type);
            } while (strcmp(type, "add") != 0 && strcmp(type, "remove") != 0);

            if (strcmp(type, "add") == 0) {
                do {
                    printf("Input quantity to add [>=1]: ");
                    scanf("%d", &qty);
                    getchar();
                } while (qty < 1);
                game->stock += qty;
                printf("Data updated succesfully!:D\n ");
            } else {
                do {
                    printf("Input quantity to remove [1-%d]: ", game->stock);
                    scanf("%d", &qty);
                    getchar();
                } while (qty < 1 || qty > game->stock);
                game->stock -= qty;
                if (game->stock == 0) {
                    root = deleteNode(root, title);
                    printf("%s removed from the warehouse!\n",title);
                }
            }
        }

    } while (menu != 4);

    return 0;
}


