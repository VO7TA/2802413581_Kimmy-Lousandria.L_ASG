#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct Data {
    char movie[100];
    int duration;
    struct Data *next;
} *head = NULL, *tail = NULL, *curr;


void push(char movie[], int duration) {
    struct Data *newNode = (struct Data*)malloc(sizeof(struct Data));
    strcpy(newNode->movie, movie);
    newNode->duration = duration;
    newNode->next = NULL;
    
    if (!head || strcmp(movie, head->movie) < 0) {
        newNode->next = head;
        head = newNode;
        if (!tail) tail = newNode;
    } else {
        curr = head;
        while (curr->next && strcmp(curr->next->movie, movie) < 0) {
            curr = curr->next;
        }
        newNode->next = curr->next;
        curr->next = newNode;
        if (!newNode->next) tail = newNode;
    }
}


void view() {
    curr = head;
    if (curr) {
        printf("%-20s : %-10s\n", "Movie Title", "Duration");
        printf("-----------------------------------------\n");
    }
    while (curr) {
        printf("%-20s : %-10d\n", curr->movie, curr->duration);
        curr = curr->next;
    }
}


void pop() {
    if (!head) return;
    if (!head->next) {
        free(head);
        head = tail = NULL;
        return;
    }
    curr = head;
    while (curr->next && curr->next->next) {
        curr = curr->next;
    }
    free(curr->next);
    curr->next = NULL;
    tail = curr;
}


void clear() {
    int i;
    for (i = 0; i < 25; i++) {
        printf("\n");
    }
}

int main() {
    char movie[100];
    int duration, menu;

    do {
        system("cls");
        view();
        printf("XXI Movie Center\n");
        printf("=============\n");
        printf("1. Insert\n");
        printf("2. Delete\n");
        printf("3. Exit\n");
        printf("Input your choice: ");
        scanf("%d", &menu);
        fflush(stdin);

        switch (menu) {
        case 1:
            do {
                printf("Insert the movie title [min. 3 character]: ");
                fgets(movie, sizeof(movie), stdin);
                movie[strcspn(movie, "\n")] = 0; 
            } while (strlen(movie) < 3);

            do {
                printf("Input the movie duration [must be multiple of 30 ]: ");
                scanf("%d", &duration);
                fflush(stdin);
            } while (duration % 30 != 0);
            
            push(movie, duration);
            break;

        case 2:
            pop();
            break;

        case 3:
            system("cls");
            printf("\n\n\n\n\n\n\n\n\tTerima kasih telah menggunakan aplikasi ini abangda lop lop");
            getchar();
        }
    } while (menu != 3);
    
    return 0;
}