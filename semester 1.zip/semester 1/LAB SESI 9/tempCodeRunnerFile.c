#include <stdio.h>

int main(){
	
	int Tcase, error=0;
	
	long long int M, N;
	
	scanf("%d", &Tcase);
	
	for(int i=0;i<T;i++){
		scanf("%lld %lld", &N, &M);
		
		long long int array[N+1];
		
		for(long long int j=0;j<N;j++){
			scanf("%lld", &array[j]);
		}
		for(long long int j=0;j<N;j++){
			if(M<array[j]){
				error++;
			}
		}
		
		long long int start=0, end=0, sum=0, Y=-1;
		
		if(error!=N){
					
		for(long long int j=0;j<N;j++){
												
			sum+=array[end];
			
			if(sum<=M){
				long long int segmen=end-start+1;
				if(segmen>Y){
					Y=segmen;
				}
			}
			
			else if(sum>M){
				
				while(sum>M){
					sum-=array[start];
				start++;
				
				}

				long long int segmen=end-start+1;
				if(segmen>Y){
					Y=segmen;
				}
				
			}
			end++;
		}
		}
		
		error=0;
		printf("Case #%d: %d\n", i+1, Y);

	}

	return 0;
}