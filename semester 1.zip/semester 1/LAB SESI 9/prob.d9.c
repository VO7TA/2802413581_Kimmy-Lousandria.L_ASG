#include <stdio.h>

int main(){

    int n;
    scanf("%d",&n);
    if ( n < 1 || n > 100){
        return 1;
    }
    int sulit = 0;
    int opi;
   
    for (int i = 0 ; i < n ; i ++){

        do {
            scanf("%d", &opi);
        }while (opi != 0 && opi != 1);
        if (opi == 1) {
            sulit = 1; 
        }
    }
    if (sulit) {
        printf("not easy\n");
    } else {
        printf("easy\n");
    }

    return 0;
}

        