#include <stdio.h>
#include <string.h>

struct mhs{
	 char name[11];
	 int nilam;
};

void sort(struct mhs *x, int y, char row[]){
		
	for(int i=0;i<y-1;i++){									
		for(int j=0;j<y-i-1;j++){
										
			if(x[j].nilam < x[j+1].nilam){								
				int temp = x[j].nilam;	
				x[j].nilam = x[j+1].nilam;
				x[j+1].nilam = temp;
			char tempo[11];
				strcpy(tempo, x[j].name);
				strcpy(x[j].name, x[j+1].name);									
				strcpy(x[j+1].name, tempo);	
									
			}															
			else if(x[j].nilam == x[j+1].nilam)                                                                       {									
				if(strcmp(x[j].name, x[j+1].name) > 0 )                                                               {								
					char tempo1[11];
				strcpy(tempo1, x[j].name);
				strcpy(x[j].name, x[j+1].name);
				strcpy(x[j+1].name, tempo1);

				}
			}
	 }
 }
	for(int i=0;i<y;i++){

		if(strcmp(row, x[i].name)==0)                                                                                  {
			printf("%d\n", i+1);
			
		}
	

	}	

}

int main(){
	
	int Tcase, k;
	
	scanf("%d", &Tcase);
	
	for(int i=0;i<Tcase;i++){
		scanf("%d", &k);getchar();
		
		struct mhs x[k];
		
		char ranking[11];
		
		for(int j=0;j<k;j++){
			scanf("%[^#]#%d", x[j].name, &x[j].nilam);getchar();
		
		}
		scanf(" %s", ranking);getchar();
		
		
		printf("Case #%d: ", i+1);
		sort(x, k, ranking);
	}
	return 0;
}
