#include <stdio.h>

void sorting(int n[], int b){
	for(int i=0;i<b-1;i++){
		for(int j=0;j<b-i-1;j++){
			if(n[j]<n[j+1]){
				int temp=n[j];
				n[j]=n[j+1];
				n[j+1]=temp;
			}
		}
	}
	if(n[0]==0){
		printf("-1");
	}
	else{
		printf("%d", n[0]);
	}
	
}


int main(){
	
	int N, M;
	
	scanf("%d %d", &N, &M);
	
	int dlm[N], klr[M];
	
	for(int i=0;i<N;i++){
		scanf("%d", &dlm[i]);
	}
	for(int i=0;i<M;i++){
		scanf("%d", &klr[i]);
	}
	for(int i=0;i<M;i++){
		for(int j=0;j<N;j++){
			if(klr[i]== dlm[j]){
				dlm[j]=0;
			}
			
		}
		
	}
	
	printf("Maximum number is ");

	sorting(dlm, N);
	puts("");
	
	return 0;
}
