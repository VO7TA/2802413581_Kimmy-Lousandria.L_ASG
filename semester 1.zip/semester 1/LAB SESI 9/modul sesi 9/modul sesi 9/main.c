#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TOOLS 100

 struct Tool {
    int record;
    char name[100];
    int QTY;
    float price;
};


//bikin kamar
void initializeFile() {
    FILE *file;
    file = fopen("hardware.txt", "w");
    if (file == NULL) {
        printf("Error creating file!\n");
        return;
    }

    for (int i = 1; i <= MAX_TOOLS; i++) {
        fprintf(file, "0| |0|0.00\n"); 
    }

    fclose(file);
    printf("File initialized with some empty records.\n");
}

// nambahin rezeki 
void addTool() {
    struct Tool v[MAX_TOOLS] = {0}; //bikin 0 dulu

    FILE *file = fopen("hardware.txt", "r+");
    if (file == NULL) {
        printf("Error opening file!\n");
        return;
    }

    int count = 0;
    while (fscanf(file, "%d|%[^|]|%d|%f\n", &v[count].record, v[count].name, &v[count].QTY, &v[count].price) == 4) {
        count++;
    }
    fclose(file);

    int record;
    printf("Enter tool record (1-100): ");
    scanf("%d", &record);getchar();
    if (record < 1 || record > MAX_TOOLS) {
        printf("Invalid record!\n");
        return;
    }

    // Input nama dan harga alat dll
    printf("Enter tool name: ");
    scanf("%[^\n]", v[record - 1].name);getchar();
    printf("Enter tool Quantity: ");
    scanf("%d", &v[record - 1].QTY);getchar();
    printf("Enter tool price: ");
    scanf("%f", &v[record - 1].price);getchar();
    v[record - 1].record = record;

    // ngesave
    file = fopen("hardware.txt", "w");
    if (file == NULL) {
        printf("Error opening file for writing!\n");
        return;
    }

    for (int i = 0; i < MAX_TOOLS; i++) {
        fprintf(file, "%d|%s|%d|%.2f\n", v[i].record, v[i].name, v[i].QTY, v[i].price);
    }

    fclose(file);
    printf("Tool added/updated successfully!\n");
}

// display inputan
void displayTools() {
    FILE *file = fopen("hardware.txt", "r");
    if (file == NULL) {
        printf("Error opening file!\n");
        return;
    }

    struct Tool v[MAX_TOOLS] = {0};
    int count = 0;

    while (fscanf(file, "%d|%[^|]|%d|%f\n", &v[count].record, v[count].name, &v[count].QTY, &v[count].price) == 4) {
        count++;
    }
    fclose(file);

    printf("\nRecord	|Tool name            |Quantity	        |Cost\n");
    for (int j = 0; j < count; j++) {
        if (v[j].record != 0) {
            printf("%d	|%-10s      |%d		|%5.2f\n", v[j].record, v[j].name, v[j].QTY, v[j].price);
        }
    }
}
// main
int main() {
    int choice;

    do {
        printf("\n===Hardware Store Inventory:===\n");
        printf("1. Initialize File\n");
        printf("2. Add/Update Tool\n");
        printf("3. Display Tools\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                initializeFile();
                break;
            case 2:
                addTool();
                break;
            case 3:
                displayTools();
                break;
            case 4:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice!\n");
        }
    } while (choice != 4);

    return 0;
}