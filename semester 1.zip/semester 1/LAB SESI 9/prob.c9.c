#include <stdio.h>
#include <stdlib.h>

void urutanarray(int arr[], int n) { //bubble sort
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

// cari pasangan ada di dalam array atau engga
void caripasangan(int mmr[], int n, int f, int kasus) {
    int adadidaftar = 0;
    for (int i = 0; i < n; i++) {
        if (mmr[i] == f) {
            adadidaftar = 1;
            break;
        }
    }

    // kalau gada
    if (!adadidaftar) {
        printf("CASE #%d: -1 -1\n", kasus);
        return;
    }

    //declarasi bubble yg di atas
    urutanarray(mmr, n);

    // Variabel untuk mmr biar bisa bedain
    int mmr1 = -1, mmr2 = -1;

    // kalau pemain lebih tinggi
    if (f == mmr[n - 1]) {
        // Cari MMR tertinggi ke yang lebih rendah ke 2
        mmr1 = mmr[n - 2];
        mmr2 = f;
    } 
    // kalau bukan MMR tertinggi
    else {
        for (int i = 0; i < n; i++) {
            // Cari MMR terendah yang lebih tinggi dri mmr terendah
            if (mmr[i] > f) {
                mmr1 = f;
                mmr2 = mmr[i];
                break;
            }
        }
    }

    // Cetak hasil
    printf("CASE #%d: %d %d\n", kasus, mmr1, mmr2);
}

int main() {
    int k;
    scanf("%d", &k);

    for (int i = 1; i <= k; i++) {
        int n;
        scanf("%d", &n);

        // Baca mmr setiap pemain
        int mmr[1000];
        for (int j = 0; j < n; j++) {
            scanf("%d", &mmr[j]);
        }

        // MMR pemain yang ingin mencari pasangan
        int f;
        scanf("%d", &f);

        // Cari pasangan
        caripasangan(mmr, n, f, i);
    }

    return 0;
}