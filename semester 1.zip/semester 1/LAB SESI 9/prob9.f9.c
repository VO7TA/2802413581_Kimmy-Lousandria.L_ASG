#include <stdio.h>

void slidingWindow(int N, int arr[], int Q, long long queries[]) {
    for (int q = 0; q < Q; q++) {
        long long tempo = queries[q];
        long long sum = 0;
        int start = 0, maxLength = -1;

        for (int end = 0; end < N; end++) {
            sum += arr[end];

            while (sum > tempo) {
                sum -= arr[start];
                start++;
            }

            int length = end - start + 1;
            if (length > maxLength) {
                maxLength = length;
            }
        }

        if (maxLength == -1) {
            printf("Case #%d: -1\n", q + 1);
        } else {
            printf("Case #%d: %d\n", q + 1, maxLength);
        }
    }
}

int main() {
    int N, Q;

    scanf("%d", &N);
    int arr[N];

    for (int i = 0; i < N; i++) {
        scanf("%d", &arr[i]);
    }

    scanf("%d", &Q);
    long long queries[Q];

    for (int i = 0; i < Q; i++) {
        scanf("%lld", &queries[i]);
    }

   
   slidingWindow(N, arr, Q, queries);

    return 0;
}
