#include <stdio.h>


int main  (){

    FILE*p = fopen()
}
