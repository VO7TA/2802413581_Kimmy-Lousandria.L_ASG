#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_FILES 101

typedef struct {
    char nama[25];
    float size;
} File;

File storage[MAX_FILES];
int fileCount = 0;

void save_File() {
    if (fileCount >= MAX_FILES) {
        printf("Storage is full.\n");
        return;
    }

    char type[10];
    char nama[25];

    printf("Enter file type [document|image]: ");
    scanf("%s", type);

    if (strcmp(type, "document") != 0 && strcmp(type, "image") != 0) {
        printf("Invalid file type.\n");
        return;
    }

    printf("Enter file name [5-20 characters]: ");
    scanf("%s", nama);

    int nameLength = strlen(nama);
    if (nameLength < 5 || nameLength > 20) {
        printf("File name must be between 5 and 20 characters.\n");
        return;
    }

    if (strcmp(type, "document") == 0) {
        strcat(nama, ".doc");
    } else if (strcmp(type, "image") == 0) {
        strcat(nama, ".jpg");
    }

    float size = ((float)rand() / RAND_MAX) * 10.0;

    strcpy(storage[fileCount].nama, nama);
    storage[fileCount].size = size;
    fileCount++;

    printf("File saved: %s (%.2f MB)\n", nama, size);
}

void history(void) {
    if (fileCount == 0) {
        printf("No files in history.\n");
        return;
    }

    printf("File History:\n");
    for (int i = 0; i < fileCount; i++) {
        printf("%d. %s (%.2f MB)\n", i + 1, storage[i].nama, storage[i].size);
    }
}

void removeAllFiles(void) {
    fileCount = 0;
    printf("All files has been removed! \n");
}

int main(void) {
    srand(time(0));
    int choice;

    do {
        printf("\nHextech File Storage\n");
        printf("=======================\n");
        printf("1. Save a File\n");
        printf("2. View History\n");
        printf("3. Remove All Files\n");
        printf("4. Exit\n");
        printf("Choose an option: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                save_File();
                break;
            case 2:
                history();
                break;
            case 3:
                removeAllFiles();
                break;
            case 4:
                printf("Thank you for using this application\n");
                break;
            default:
                printf("Invalid option. Please choose again.\n");
        }
    } while (choice != 4);

    return 0;
}
