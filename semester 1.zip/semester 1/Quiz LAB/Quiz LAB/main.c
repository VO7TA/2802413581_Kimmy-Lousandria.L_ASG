#include <stdio.h>
#include <string.h>

int main(){
    
    int a = 0, b = 0, c = 0, nilai = 0;
    puts("Menu Navigasi");
    puts(" 1. Positive or Negative\n 2. Grading \n 3. Largest Number");
    
    int Tcase;
    printf("Pilihan Menu : ");
    scanf("%d",&Tcase);
    
    
    switch (Tcase)
    {
        case 1:
            printf("Masukkan 3 angka : ");
            scanf("%d %d %d",&a,&b,&c);
            int min = 0;
            
            if ( a < 0) min++;
            if ( b < 0) min++;
            if ( c < 0) min++;
            
            if(min == 0){
                printf("Tidak ada Angka negatif\n");
            }else {
                printf("%d angka negatif\n", min);
                break;
            
        }
        case 2:
            printf("Menu Nilai\n");
            printf("Masukkan nilai : ");
            scanf("%d", &nilai);
            
            if ( nilai > 0 && nilai < 50 ){
                printf("Grade E");
            }else if (nilai > 49 && nilai < 65  ){
                printf("Grade D");
            }else if (nilai > 64 && nilai < 70  ){
                printf("Grade C");
            } else if (nilai > 69 && nilai < 85  ){
                printf("Grade B");
            } else if (nilai > 84 && nilai < 101  ){
                printf("Grade A");
            } else{
                printf("Nilai apa tuh bang?");
            } break;
            
        case 3 :
            printf("Masukkan 3 Angka :");
            scanf("%d %d %d",&a,&b,&c);
            int jurdun = a;

            if (b > jurdun) {
                jurdun = b;
            }

            if (c > jurdun) {
                jurdun = c;
            }

            printf("angka terbesar adalah : %d\n", jurdun);
            default: printf("Pilihan anda tidak valid, coba lagi.\n");
            break;
         }
                
        
    return 0;
}



