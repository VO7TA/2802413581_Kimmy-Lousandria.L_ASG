#include <stdio.h>

int main(){
    
    int bola,voli;
    
    scanf("%d %d", &bola, &voli);
    printf("%d\n", bola%voli);
    
    return 0;
}

