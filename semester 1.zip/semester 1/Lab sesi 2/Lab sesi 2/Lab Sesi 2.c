#include <stdio.h>
int main(){
    
    int a;
    int b;
    
    printf("Masukkan angka pertama : \n");
        scanf("%d", &a);
    
    printf("Masukkan angka kedua : \n");
        scanf("%d",&b);
    
    int jumlah = a + b ;
    printf("Hasil jumlah dari dua bilangan tersebut adalah : %d \n", jumlah);
        int perkalian = a*b;
        printf("Hasil pengurangan dari dua bilangan tersebut adalah : %d \n", perkalian);
            int pengurangan = a - b;
            printf("Hasil pengurangan dari dua bilangan tersebut adalah : %d \n", pengurangan);
                    printf("Hasil pembagian dari dua bilangan tersebut adalah : %.2f \n", (float) a/b);
                                int modulus = a%b;
                                printf("Hasil modulus dari dua bilangan tersebut adalah : %d \n",modulus);
                            
                    
    
}
