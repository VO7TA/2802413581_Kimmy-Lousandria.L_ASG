#include <stdio.h>

double ream(double celci) {
    return celci * 4.0 / 5.0;
}

double  faren(double celci) {
    return (celci * 9.0 / 5.0) + 32;
}

double kelvi(double celci) {
    return celci + 273;
}

int main(){
    
    int tole,i;
    double celci;

    scanf("%d",&tole);
    
    for (i=0 ; i < tole ; i++){
        scanf ("%lf",&celci);
        double reamur = ream(celci) ;
        double fahrenheit = faren(celci);
        double kelvin = kelvi(celci);
        printf("%.2lf %.2lf %.2lf\n", reamur, fahrenheit, kelvin);
    }
   
    
    
    
    return 0;
}



