#include <stdio.h>
#include <math.h>

int main() {
    
    int phy,mge,td;
    double total;
    scanf("%d %d %d", &phy,&mge,&td);
    
    total = (phy * 0.20) + (mge * 0.30) + (td * 0.50);
    
    printf("%.2f\n",total );
    
    
    return 0;
}
