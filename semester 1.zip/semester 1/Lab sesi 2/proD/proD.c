#include <stdio.h>
#include <math.h>

int main() {
    
    int haw,hir;
    double diskon;
    
    scanf("%d %d", &haw,&hir);
    
    diskon = ((double)(haw-hir)/ haw) * 100;
    diskon = round(diskon * 100)/100;
    
    printf("%.2lf%%\n",diskon);
    return 0;
}
