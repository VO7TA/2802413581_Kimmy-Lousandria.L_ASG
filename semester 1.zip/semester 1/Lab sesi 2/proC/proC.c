#include <stdio.h>
#include <math.h>

int main (){
    
    double z;
    double x;
    double c;
    int n = 3;

    scanf("%lf %lf", &z, &c);

    double r = c / 100;

    c = z * pow((1 + r), n);

    printf("%.2lf\n", c);

    return 0;
}
