#include <stdio.h>
#include <string.h>

int main(){
    
    puts("\t\t\t\t Blue's Car");
    puts("\t\t\t====================");
    puts("Welcome to Blue's Car Price Simulator");
    puts("Todays Date: October 31th 2016");
    
    char type[21]; int purchase;
    printf("Please Input your car type [2..20]: \n");
    scanf("%s",type);
    int panjang = strlen(type);
    while (panjang > 2 && panjang < 21) {
        printf("\n\n");
        printf("*we cannot buy 1 year old car:)\n");
        
        do {
            printf("Please input purchasing year of the car [2000 - 2014]: ");
            scanf("%d",&purchase);
        }while ( purchase > 2000 && purchase < 2015 );
            printf("")
            
    
    return 0;
}
