#include<stdio.h>
#include<string.h>

struct barber{	//kimmy
	int date, month, year, price;
	char c_name[101], service_type, service_name[101], b_name[101], rate[10];
};

void input(){	//kimmy
	FILE *f=fopen("sales.txt", "r");
	
	struct barber b[100];
	int count=0;
	
	while(fscanf(f, "%d/%d/%d|%[^|]|%c|%[^|]|%[^|]|%d|%[^\n]\n", &b[count].date, &b[count].month, &b[count].year, b[count].c_name, &b[count].service_type, b[count].service_name, b[count].b_name, &b[count].price, b[count].rate)!=EOF){
		count++;
	}
	fclose(f);

	char answer, c[]= "Haircut", d[]= "Hairdye", p[]="Perm", a[]="Basic", s[]="Super", r[]="Supreme";
	char cb[]="Curly Basic", cs[]="Curly Super", db[]="Down Basic", ds[]="Down Super";
	
	while(answer!='n'){
		printf("Input date [DD/MM/YYYY]: ");scanf("%d/%d/%d", &b[count].date, &b[count].month, &b[count].year);getchar();
		printf("Input customer name [lowercase]: ");scanf("%[^\n]", b[count].c_name);getchar();
		
		do {
			printf("Input service type [C for %s, D for %s, P for %s]: ", c, d, p);scanf("%c", &b[count].service_type);getchar();
		} while(b[count].service_type!='C'&&b[count].service_type!='D'&&b[count].service_type!='P');
		
			if (b[count].service_type=='C'){
				do{
					printf("Input %s name [%s, %s, %s]: ", c, a, s, r);scanf("%s", b[count].service_name);getchar();
				}while(strcmp(b[count].service_name, a)!=0&&strcmp(b[count].service_name, s)!=0&&strcmp(b[count].service_name, r)!=0);
				
				if (strcmp(b[count].service_name, a)== 0){
					b[count].price=25;
				}else if (strcmp(b[count].service_name, s)== 0){
					b[count].price=50;
				}else if (strcmp(b[count].service_name, r)== 0){
					b[count].price=100;
				}
			}
			else if (b[count].service_type=='D'){
				do{
				printf("Input %s name [%s, %s]: ", d, a, s);scanf("%s",b[count].service_name);getchar();
				}while(strcmp(b[count].service_name, a)!=0&&strcmp(b[count].service_name, s)!=0);

				if (strcmp(b[count].service_name, a)== 0){
					b[count].price=40;
				}else if (strcmp(b[count].service_name, s)== 0){
					b[count].price=65;
				}
			}
			else if (b[count].service_type=='P'){
				do{
				printf("Input %s name [%s, %s, %s, %s]: ", p, cb, cs, db, ds);scanf("%[^\n]",b[count].service_name); getchar();
				}while(strcmp(b[count].service_name, cb)!=0&&strcmp(b[count].service_name, cs)!=0&&strcmp(b[count].service_name, db)!=0&&strcmp(b[count].service_name, ds)!=0);

				
				if (strcmp ( b[count].service_name, cb)== 0){
					b[count].price = 250;
				}else if (strcmp ( b[count].service_name, cs)== 0){
					b[count].price = 275;
				}else if (strcmp ( b[count].service_name, db)== 0){
					b[count].price = 500;
				}else if (strcmp ( b[count].service_name, ds)== 0){
					b[count].price = 550;
				}
			}
			
		printf("Input barber name [lowercase]: ");scanf("%[^\n]", b[count].b_name);getchar();
		
		do {
			printf("Input rate [*]: ");scanf("%s", b[count].rate);getchar();
		}while(strlen(b[count].rate)>5);
		
		do{
			printf("Input again [y/n]: ");scanf("%c", &answer);getchar();
		}while(answer!='y'&&answer!='n');
		
		count++;
	}
	
	f=fopen("sales.txt", "w");
	for(int i=0;i<count;i++){
		fprintf(f, "%d/%d/%d|%s|%c|%s|%s|%d|%s\n", b[i].date, b[i].month, b[i].year, b[i].c_name, b[i].service_type, b[i].service_name, b[i].b_name, b[i].price, b[i].rate);
	}
	
	fclose(f);
}

void update(){	//kimmy
	struct barber b[100];
	FILE *f=fopen("sales.txt", "r");
	int count=0;
	
	while(fscanf(f, "%d/%d/%d|%[^|]|%c|%[^|]|%[^|]|%d|%[^\n]\n", &b[count].date, &b[count].month, &b[count].year, b[count].c_name, &b[count].service_type, b[count].service_name, b[count].b_name, &b[count].price, b[count].rate)!=EOF){
		count++;
	}
	fclose(f);
	
	puts("Id	|DD/MM/YYYY	|Customer Name	|Service Type	|Service Name	|Barber Name	|Price	|Rate");
	puts("-------------------------------------------------------------------------------------------------------");


for(int i=0;i<count;i++){
		printf("%d	|%02d/%d/%d	|%-10s	|%c		|%-10s	|%-10s	|$%d	|%-10s\n", i+1, b[i].date, b[i].month, b[i].year, b[i].c_name, b[i].service_type, b[i].service_name, b[i].b_name, b[i].price, b[i].rate);

}

puts("------------------------------------------------------------------------------------------------------");

int up, check=0;
char c[]= "Haircut", d[]= "Hairdye", p[]="Perm", a[]="Basic", s[]="Super", r[]="Supreme";
	char cb[]="Curly Basic", cs[]="Curly Super", db[]="Down Basic", ds[]="Down Super";
		
			printf("Which id you want update: ");scanf("%d", &up);getchar();
			int index=up-1;
			
	if(b[index].date!='\0'){
	
		printf("Input date [DD/MM/YYYY]: ");scanf("%d/%d/%d", &b[index].date, &b[index].month, &b[index].year);getchar();
		printf("Input customer name [lowercase]: ");scanf("%[^\n]", b[index].c_name);getchar();
		
		do {
			printf("Input service type [C for %s, D for %s, P for %s]: ", c, d, p);scanf("%c", &b[index].service_type);getchar();
		} while(b[index].service_type!='C'&&b[index].service_type!='D'&&b[index].service_type!='P');
		
			if (b[index].service_type=='C'){
				do{
					printf("Input %s name [%s, %s, %s]: ", c, a, s, r);scanf("%s", b[index].service_name);getchar();
				}while(strcmp(b[index].service_name, a)!=0&&strcmp(b[index].service_name, s)!=0&&strcmp(b[index].service_name, r)!=0);
				
				if (strcmp(b[index].service_name, a)== 0){
					b[index].price=25;
				}else if (strcmp(b[index].service_name, s)== 0){
					b[index].price=50;
				}else if (strcmp(b[index].service_name, r)== 0){
					b[index].price=100;
				}
			}
			else if (b[index].service_type=='D'){
				do{
				printf("Input %s name [%s, %s]: ", d, a, s);scanf("%s",b[index].service_name);getchar();
				}while(strcmp(b[index].service_name, a)!=0&&strcmp(b[index].service_name, s)!=0);

				if (strcmp(b[index].service_name, a)== 0){
					b[index].price=40;
				}else if (strcmp(b[index].service_name, s)== 0){
					b[index].price=65;
				}
			}
			else if (b[index].service_type=='P'){
				do{
				printf("Input %s name [%s, %s, %s, %s]: ", p, cb, cs, db, ds);scanf("%[^\n]",b[index].service_name); getchar();
				}while(strcmp(b[index].service_name, cb)!=0&&strcmp(b[index].service_name, cs)!=0&&strcmp(b[index].service_name, db)!=0&&strcmp(b[index].service_name, ds)!=0);

				
				if (strcmp(b[index].service_name, cb)== 0){
					b[index].price = 250;
				}else if(strcmp(b[index].service_name, cs)== 0){
					b[count].price = 275;
				}else if(strcmp(b[index].service_name, db)== 0){
					b[index].price = 500;
				}else if(strcmp(b[index].service_name, ds)== 0){
					b[index].price = 550;
				}
			}
			
		printf("Input barber name [lowercase]: ");scanf("%[^\n]", b[index].b_name);getchar();
		
		do {
			printf("Input rate [*]: ");scanf("%s", b[index].rate);getchar();
		}while(strlen(b[index].rate)>5);
		check=1;
		
	}

if(check==0) printf("Id not found!\n");

f=fopen("sales.txt", "w");

for(int i=0;i<count;i++){
		fprintf(f, "%d/%d/%d|%s|%c|%s|%s|%d|%s\n", b[i].date, b[i].month, b[i].year, b[i].c_name, b[i].service_type, b[i].service_name, b[i].b_name, b[i].price, b[i].rate);
	}
fclose(f);

}

void deleted(){		//vincent
	struct barber b[100];
	FILE *f=fopen("sales.txt", "r");
	int count=0;
	
	while(fscanf(f, "%d/%d/%d|%[^|]|%c|%[^|]|%[^|]|%d|%[^\n]\n", &b[count].date, &b[count].month, &b[count].year, b[count].c_name, &b[count].service_type, b[count].service_name, b[count].b_name, &b[count].price, b[count].rate)!=EOF){
		count++;
	}
	fclose(f);
	
		puts("Id	|DD/MM/YYYY	|Customer Name	|Service Type	|Service Name	|Barber Name	|Price	|Rate");
	puts("-------------------------------------------------------------------------------------------------------");


for(int i=0;i<count;i++){
		printf("%d	|%02d/%d/%d	|%-10s	|%c		|%-10s	|%-10s	|$%d	|%-10s\n", i+1, b[i].date, b[i].month, b[i].year, b[i].c_name, b[i].service_type, b[i].service_name, b[i].b_name, b[i].price, b[i].rate);

}

puts("------------------------------------------------------------------------------------------------------");

int del= 0;
printf("Which id do you want to delete: ");scanf("%d",&del);getchar();

int index=del-1, check=0;


	if(b[index].date!='\0'){
		b[index].date='\0';
		b[index].month='\0';			
		b[index].price='\0';
		strcpy(b[index].rate, "");
		strcpy(b[index].service_name, "");
		b[index].service_type='\0';
	    b[index].year='\0';
	    strcpy(b[index].b_name, "");
	    strcpy(b[index].c_name, "");
	check=1;
	
	}

	if (check==0) printf("Id not found\n");
	
	f=fopen("sales.txt", "w");

for(int i=0;i<count;i++){
	if(b[i].date!='\0'){
		fprintf(f, "%d/%d/%d|%s|%c|%s|%s|%d|%s\n", b[i].date, b[i].month, b[i].year, b[i].c_name, b[i].service_type, b[i].service_name, b[i].b_name, b[i].price, b[i].rate);
	}
}
fclose(f);
}

void list(){	//yosuke
	
	struct barber b[100];
	struct barber B[100];
	FILE *f=fopen("sales.txt", "r");
	
	int count=0, option, sort=0, search=0, hitung=0, cos=0;
	
	while(fscanf(f, "%d/%d/%d|%[^|]|%c|%[^|]|%[^|]|%d|%[^\n]\n", &b[count].date, &b[count].month, &b[count].year, b[count].c_name, &b[count].service_type, b[count].service_name, b[count].b_name, &b[count].price, b[count].rate)!=EOF){
		count++;
	}
	fclose(f);

	puts("1. Sorting");
	puts("2. Searching");

	printf("Choose menu >> ");scanf("%d", &option);getchar();

	switch (option){
		case 1 :
			sort=1;
			puts("\n1. Sort by date");
			puts("2. Sort by customer name");
			puts("3. Sort by barber name ");
			puts("4. Sort by rate ");
			int sr, ad;
			do{
				printf("Choose menu >> ");scanf("%d", &sr);getchar();
			}while(sr<1&&sr>4);
			
			
			switch (sr){
				case 1:
					puts("\n1. Oldest");
					puts("2. Latest");
					printf("Choose menu >> ");scanf("%d",&ad);getchar();
					
					switch (ad){
						case 1 :
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(b[j].year>b[j+1].year){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(b[j].year==b[j+1].year){
							if(b[j].month>b[j+1].month){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							}
		
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(b[j].year==b[j+1].year&&b[j].month==b[j+1].month){
							if(b[j].date>b[j+1].date){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							}
					break;
					case 2:
							for(int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(b[j].year<b[j+1].year){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(b[j].year==b[j+1].year){
							if(b[j].month<b[j+1].month){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							}
		
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(b[j].year==b[j+1].year&&b[j].month==b[j+1].month){
							if(b[j].date<b[j+1].date){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							}
						break;
					}
					break;
				case 2:
					puts("\n1. Acending");
					puts("2. Descending");
					printf("Choose menu >> ");scanf("%d",&ad);getchar();
					switch (ad){
						case 1:
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(strcmp(b[j].c_name, b[j+1].c_name)>0){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							break;
						case 2:
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(strcmp(b[j].c_name, b[j+1].c_name)<0){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							break;
						}
						
				break;
				case 3:
					puts("\n1. Acending");
					puts("2. Descending");
					printf("Choose menu >> ");scanf("%d",&ad);getchar();
					switch (ad){
						case 1:
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(strcmp(b[j].b_name, b[j+1].b_name)>0){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							break;
						case 2:
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(strcmp(b[j].b_name, b[j+1].b_name)<0){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							break;
						}
						
					
						break;
				case 4:
					puts("\n1. Acending");
					puts("2. Descending");
					printf("Choose menu >> ");scanf("%d",&ad);getchar();
					switch (ad){
						
					case 1:
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(strcmp(b[j].rate, b[j+1].rate)>0){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							break;
						case 2:
							for (int i=0;i<count-1;i++){
							for(int j=0;j<count-i-1;j++){
							if(strcmp(b[j].rate, b[j+1].rate)<0){
							struct barber temp=b[j];
							b[j]=b[j+1];
							b[j+1]=temp;
							}
							}
							}
							break;
						}
					break;
		
}
break;
case 2:
	search=1;
		puts("\n1. Search by date");
		puts("2. Search by month");
		puts("3. Search by year");
		puts("4. Search by customer name");
		puts("5. Search by barber name ");
		puts("6. Search by service type");
		puts("7. Search by service name");
		puts("8. Search by rate ");
		int sc, ins;
		char nm[101], ch;
		
		printf("Choose menu >> ");scanf("%d", &sc);getchar();
			switch (sc){
				case 1:
					printf("Input date you wanna search: ");scanf("%d", &ins);getchar();
					for(int i=0;i<count;i++){
						if(b[i].date==ins){
							B[hitung]=b[i];
							hitung++;
							cos=1;
						}
						
					}
					break;
				case 2:
					printf("Input month you wanna search: ");scanf("%d", &ins);getchar();
					for(int i=0;i<count;i++){
						if(b[i].month==ins){
							B[hitung]=b[i];
							hitung++;
							cos=1;
						}
						
					}
					break;
				case 3:
					printf("Input year you wanna search: ");scanf("%d", &ins);getchar();
					for(int i=0;i<count;i++){
						if(b[i].year==ins){
							B[hitung]=b[i];
							hitung++;
							cos=1;
						}
						
					}
					break;
				case 4:
					printf("Input customer name you wanna search [lowercase]: ");scanf("%[^\n]", nm);getchar();
					for(int i=0;i<count;i++){
						if(strcmp(b[i].c_name, nm)==0){
							B[hitung]=b[i];
							hitung++;
							cos=1;
						}
						
					}
					break;
				case 5:
					printf("Input barber name you wanna search [lowercase]: ");scanf("%[^\n]", nm);getchar();
					for(int i=0;i<count;i++){
						if(strcmp(b[i].b_name, nm)==0){
							B[hitung]=b[i];
							hitung++;
							cos=1;
						}
					}
					break;
				case 6:
					do{
						printf("Input service type you wanna search [C, D, P]: ");scanf("%s", &ch);getchar();
					}while(ch!='C'&&ch!='D'&&ch!='P');
					
					for(int i=0;i<count;i++){
						if(b[i].service_type==ch){
							B[hitung]=b[i];
							hitung++;
							cos=1;
						}
					}
					break;
				case 7:
					printf("Input service name you wanna search [Basic, Super, Supreme]: ");scanf("%s", nm);getchar();
					for(int i=0;i<count;i++){
						if(strcmp(b[i].service_name, nm)==0){
							B[hitung]=b[i];
							hitung++;
							cos=1;
						}
					}
					break;
				case 8:
					do{
						printf("Input rate you wanna search [*]: ");scanf("%s", nm);getchar();
					}while(strlen(nm)>5);
					
					for(int i=0;i<count;i++){
						if(strcmp(b[i].rate, nm)==0){
							B[hitung]=b[i];
							hitung++;
							cos=1;
						}
					}
					break;
			}
			break;
		}
		
if(search==1){
	if(cos==1){
	
	puts("\n|DD/MM/YYYY	|Customer Name	|Service Type	|Service Name	|Barber Name	|Price	|Rate");
	puts("----------------------------------------------------------------------------------------------");
	for(int i=0;i<hitung;i++){
		printf("|%02d/%d/%d	|%-10s	|%c		|%-10s	|%-10s	|$%d	|%-10s\n", B[i].date, B[i].month, B[i].year, B[i].c_name, B[i].service_type, B[i].service_name, B[i].b_name, B[i].price, B[i].rate);
}
puts("----------------------------------------------------------------------------------------------");
}
else if(cos==0) printf("Data not found\n");
}

else if(sort==1){
puts("\n|DD/MM/YYYY	|Customer Name	|Service Type	|Service Name	|Barber Name	|Price	|Rate");
	puts("----------------------------------------------------------------------------------------------");
for(int i=0;i<count;i++){
		printf("|%02d/%d/%d	|%-10s	|%c		|%-10s	|%-10s	|$%d	|%-10s\n", b[i].date, b[i].month, b[i].year, b[i].c_name, b[i].service_type, b[i].service_name, b[i].b_name, b[i].price, b[i].rate);
}
puts("----------------------------------------------------------------------------------------------");
}
else if(search==0) printf("There is no data\n");

else if(sort==0) printf("There is no data\n");





}

int main(){	//vincent
	
	int menu;
	
	do{
		
	puts("Barber Cak Telo");
	puts("--------------------");
	puts("1. Input data sale");
	puts("2. Update data sale");
	puts("3. Delete data sale");
	puts("4. List data sale");
	puts("5. Exit");
	puts("--------------------");
	printf("Choose menu: ");scanf("%d", &menu);getchar();
	puts("");
	
	switch (menu){
		case 1:
			input();
			printf("\nSucess.. Press enter to continue..");getchar();
			puts("");
			break;
		case 2:
			update();
			printf("\nSucess.. Press enter to continue..");getchar();
			puts("");
			break;
		case 3:
			deleted();
			printf("\nSucess.. Press enter to continue..");getchar();
			puts("");
			break;
		case 4 :
			list();
			printf("\nSucess.. Press enter to continue..");getchar();
			puts("");
			break;
			
	}
}while(menu!=5);

printf("Thank You!");

	
	
	return 0;
}
