#include <stdio.h>

int recFunc(int x) {
    if (x <= 4) {
        return x;
    } else {
        return (recFunc(x / 5) + (x % 5)) / 5;
    }
}

int main() {
    int T, x;
    
    scanf("%d", &T);
    
    for (int i = 1; i <= T; i++) {
        scanf("%d", &x);
        
        printf("Case #%d: %d\n", i, recFunc(x));
    }
    
    return 0;
}
