/* file processing
extension CSV? 

defenisi stream : intinya kalau kaian bikin file kalian menyimpan storage dalam bentuk oepn file
yang disimpan di hardisk

stream dibagi jadi 3 
- input = contohnya, keyboard, dll ( yg masuk ke kkomputer)
- output= yg keluar dri komputer
- eror  = tersimpan base eror

setiap strenm terhubung oleh file

file = kumpulan dri record
struck/record = 1 kumpulan dri variable dri kumpulan tipe data berbeda

1 interger =4 byte

field = kumpulan dri byte
byte = kumpulan dri bit 
array = 1 kumpulan dri variable dri kumpulan tipe data sejenis

input stream pointer = stdin
output stream pointer = stdout
error stream pointer = stderr

syntax :
 FILE *(nama);
(nama) adalah file pointer menunjuk to start the buffer area

buffer area = tersimpan di dalam ram, 

#OPEN FILE

FILE 
(nama pointer p) = fopen("nama file","mode file")
fopen = membuka file dan mengkocopy file asli ke buffer area

mode ada 8 (HAFALKAN)!

r = baca file, file harus ada
W = creating file , jika file sudah ada maka akan mengkosongi file awal
a = menambah file( gabungan dri A dan W), file harus ada
r+ = File yg dibuka bisa ditulis juga , File harus ada, gabungan dri a dan w namun file harus ada
w+ = mirip r+, file ga harus ada
a+ = bisa baca sambil melek
rb = buka file binary buat dibaca 
wb = bikin file binary buar ditulis


fscanf(INPUT)(membaca)
syntax = intfscanf( pointer FILE ,"%d\n", alamat);
fprintf(output)(menulis)
syntax = fprintf(pointer FILE, "kata kata",alamat);

feof = 

fscanf(p,"%d|%[^|]|%f\n", &x[jml],nama[jml],&ipk[jml]);

#CLOSE FILE
 */ 

































//*