#include <stdio.h>

int main(){
    
    int d,e;
    
    scanf("%d %d",&d ,&e);
    printf("%d\n", d + e);
    
}
