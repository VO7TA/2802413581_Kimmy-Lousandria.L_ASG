#include <stdio.h>
#include <string.h>

typedef struct {
    char nama_ayah[31];
    char nama_ibu[31];
    int jumlah_saudara;
} Keluarga;

typedef struct {
    char kode[31];
    char nama[31];
    char gender[15];
    Keluarga keluarga;
} Mahasiswa;

typedef struct {
    char kode[31];
    char nama[31];
    char gender[15];
    int jumlah_mahasiswa;
    Mahasiswa mahasiswanya[100];
} Dosen;

int main() {
    int N, K, i, j;
    Dosen dosen[100];

    
    scanf("%d", &N);

    for (i = 0; i < N; i++) {
        scanf("%s", dosen[i].kode);
        scanf("%s", dosen[i].nama);
        scanf("%s", dosen[i].gender);
        scanf("%d", &dosen[i].jumlah_mahasiswa);

        for (j = 0; j < dosen[i].jumlah_mahasiswa; j++) {
            Mahasiswa *mhs = &dosen[i].mahasiswanya[j];
            scanf("%s", mhs->kode);
            scanf("%s", mhs->nama);
            scanf("%s", mhs->gender);
            scanf("%s", mhs->keluarga.nama_ayah);
            scanf("%s", mhs->keluarga.nama_ibu);
            scanf("%d", &mhs->keluarga.jumlah_saudara);
        }
    }

    scanf("%d", &K);
    K--;

    printf("Kode Dosen: %s\n", dosen[K].kode);
    printf("Nama Dosen: %s\n", dosen[K].nama);
    printf("Gender Dosen: %s\n", dosen[K].gender);
    printf("Jumlah Mahasiswa: %d\n", dosen[K].jumlah_mahasiswa);

    for (i = 0; i < dosen[K].jumlah_mahasiswa; i++) {
        Mahasiswa *mhs = &dosen[K].mahasiswanya[i];
        printf("Kode Mahasiswa: %s\n", mhs->kode);
        printf("Nama Mahasiswa: %s\n", mhs->nama);
        printf("Gender Mahasiswa: %s\n", mhs->gender);
        printf("Nama Ayah: %s\n", mhs->keluarga.nama_ayah);
        printf("Nama Ibu: %s\n", mhs->keluarga.nama_ibu);
        printf("Jumlah Saudara Kandung: %d\n", mhs->keluarga.jumlah_saudara);
    }

    return 0;
}
