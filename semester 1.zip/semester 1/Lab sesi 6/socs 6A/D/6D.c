#include <stdio.h>

int main() {
    int T, N, X, i, j, temp, swaps;
    int arr[500];

    scanf("%d", &T);
    
    for (int testcase = 1; testcase <= T; testcase++) {
        scanf("%d %d", &N, &X);
        
        for (i = 0; i < N; i++) {
            scanf("%d", &arr[i]);
        }
        
        swaps = 0;
        for (i = 0; i < N-1; i++) {
            for (j = 0; j < N-i-1; j++) {
                if (arr[j] > arr[j+1]) {

                    temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                    swaps++;
                }
            }
        }
        
       
        printf("Case #%d: %d\n", testcase, swaps * X);
    }
    
    return 0;
}
