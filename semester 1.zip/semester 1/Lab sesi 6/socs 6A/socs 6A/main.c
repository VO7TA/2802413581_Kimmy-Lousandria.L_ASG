#include <stdio.h>
#include <string.h>

struct Mahasiswa{
    
        char nama[101];
        char nim[10];
        int umur;
        int kodePos;
        char placeLahir[101];
        char dateLahir[101];
        char almamaterSMA[101];
        int jumlahbasudara;
        int tinggiBadan;
        char nomorRekening[10];
};

int main(void){
    
    int n;
    
    scanf("%d", &n);getchar();
    
    struct Mahasiswa ajaib[n];
    
    for(int i=0;i<n;i++){
        scanf("%s", ajaib[i].nama);getchar();
        scanf("%s", ajaib[i].nim);getchar();
        scanf("%d", &ajaib[i].umur);getchar();
        scanf("%d", &ajaib[i].kodePos);getchar();
        scanf("%s", ajaib[i].placeLahir);getchar();
        scanf("%s", ajaib[i].dateLahir);getchar();
        scanf("%[^\n]", ajaib[i].almamaterSMA);getchar();
        scanf("%d", &ajaib[i].jumlahbasudara);getchar();
        scanf("%d", &ajaib[i].tinggiBadan);getchar();
        scanf("%s", ajaib[i].nomorRekening);getchar();
    }
    for(int i=0;i<n;i++){
        printf("Mahasiswa ke-%d:\n", i+1);
        printf("Nama: %s\n", ajaib[i].nama);
        printf("NIM: %s\n", ajaib[i].nim);
        printf("Umur: %d\n", ajaib[i].umur);
        printf("Kode Pos: %d\n", ajaib[i].kodePos);
        printf("Tempat Lahir: %s\n", ajaib[i].placeLahir);
        printf("Tanggal Lahir: %s\n", ajaib[i].dateLahir);
        printf("Almamater SMA: %s\n", ajaib[i].almamaterSMA);
        printf("Jumlah Saudara Kandung: %d\n", ajaib[i].jumlahbasudara);
        printf("Tinggi Badan: %d\n", ajaib[i].tinggiBadan);
        printf("NOMOR REKENING: %s\n", ajaib[i].nomorRekening);
    }
    
    return 0;
}
