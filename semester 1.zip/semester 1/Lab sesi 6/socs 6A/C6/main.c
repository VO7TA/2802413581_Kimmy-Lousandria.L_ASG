
#include <stdio.h>
#include <string.h>

int main(void) {
    int N, i, j;
    char judul[100][11];
    int deadline[100];

    scanf("%d", &N);

    for (i = 0; i < N; i++)
        scanf("%s %d", judul[i], &deadline[i]);

    for (i = 0; i < N-1; i++) {
        for (j = 0; j < N-i-1; j++) {
            if (deadline[j] > deadline[j+1] ||
               (deadline[j] == deadline[j+1] &&
                strcmp(judul[j], judul[j+1]) > 0)) {
               
                int temp_deadline = deadline[j];
                deadline[j] = deadline[j+1];
                deadline[j+1] = temp_deadline;

                char temp_judul[11];
                strcpy(temp_judul, judul[j]);
                strcpy(judul[j], judul[j+1]);
                strcpy(judul[j+1], temp_judul);
            }
        }
    }

    for (i = 0; i < N; i++)
        printf("%s\n", judul[i]);

    return 0;
}
