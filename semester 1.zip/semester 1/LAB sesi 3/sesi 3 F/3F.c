#include <stdio.h>

int main() {
    int ninot;
    int i = 0;

    scanf("%d", &ninot);
    
    if (ninot < 0 || ninot > 5000) {
    }
        for (int j = 0 ; j <= ninot; j++) {
            for (int l = 0; l <= ninot - j; l++) {
                int b = ninot - j - l;
                if (b >= 0) {
                    i++;

                }
            }
        }
    printf("%d\n", i);

    return 0;
}
