#include <stdio.h>

int main() {
    int max , lando,leclerc ,jurdun;

    printf("Masukkan tiga Angka : ");
    scanf("%d %d %d", &max, &lando, &leclerc);

    jurdun = max;

    if (lando > jurdun) {
        jurdun = lando;
    }

    if (leclerc > jurdun) {
        jurdun = leclerc;
    }

    printf("angka terbesar adalah : %d\n", jurdun);

    return 0;
}
