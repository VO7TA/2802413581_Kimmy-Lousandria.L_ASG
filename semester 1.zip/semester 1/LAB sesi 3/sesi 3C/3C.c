#include <stdio.h>

int main() {
    
        int O, P, L;
        scanf("%d", &O);
        
        for (int i = 1; i <= O; i++) {
            scanf("%d %d", &P, &L);
            printf("Case #%d: %s\n", i, P >= L ? "Go-Jo" : "Bi-Pay");
        }
        return 0;
    }
