#include <stdio.h>

int main() {
    
    int dck;
    int i;
    int jck ;
    scanf("%d",&dck);
    
    
    for ( i = 0; i < dck; i++) {
        for ( jck = 0; jck < dck; jck++) {
            printf(" *");
        }
        printf("\n");
    }

    
    return 0;
}
