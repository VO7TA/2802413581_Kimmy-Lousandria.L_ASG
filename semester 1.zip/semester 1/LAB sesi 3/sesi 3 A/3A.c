
#include <stdio.h>

int main(){
    
    int caonima;
    int wongba;
    int i;
    scanf("%d %d",&caonima,&wongba);
    
    for ( i = 0; i <= wongba; i++){
        printf("%d\n",caonima + i);
    }
    return 0;
}
