
#include <stdio.h>

int main(){
    int c,w=1;
    scanf("%d", &c);
    while (w<=c){
        int zuzuzu;
        int kntl = 0;
        char xcio[101] = "";
        scanf("%s", xcio);
        for(zuzuzu = 0; zuzuzu <= 101; zuzuzu++){
            if(xcio[zuzuzu] == '.'){
                if (xcio[zuzuzu-1] != '.' && xcio[zuzuzu+1] != '.'){
                    kntl++;
                }
            }
        }
   
        if(kntl == 5){
            printf("Case #%d: YES\n", w);
        }else {
            printf("Case #%d: NO\n", w);
        }
        w++;
    }
    return 0;
}
