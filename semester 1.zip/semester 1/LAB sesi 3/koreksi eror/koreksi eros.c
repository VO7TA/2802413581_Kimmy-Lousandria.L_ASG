
#include <stdio.h>

int main(){
    
    int n;
    scanf("%d",&n);
//    eror karena "n" belum di deklarasikan dan belum bisa di input
    switch (n) {
        case 1:
            printf( "The number is 1\n" );
            break;
//            kurang break untuk case 1
        case 2:
            printf( "The number is 2\n" );
            break;
        default:
            printf( "The number is not 1 or 2\n" );
            break;
    }
    return 0;
}

