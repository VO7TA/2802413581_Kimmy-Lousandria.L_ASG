#include <stdio.h>

int main() {
    int x, y, z;
    scanf("%d %d %d", &x, &y, &z);

    int p = -1;

    for (int i = 0; i <= 100; i++) {
        int lanlift_satu = x + i;
        int lanlift_kedua = y - i;

        if (lanlift_satu == z && lanlift_kedua == z) {
            p = i;
            break;
        }
    }

    printf("%d\n", p);
    return 0;
}
    

