#include <stdio.h>

void Bs(int array[], int size){
    for( int s = 0; s < size - 1; ++s){
        for( int a = 0; a < size - s - 1 ; ++a){
            if( array [a] > array [a+1]){
                
                int swap = array[a];
                array[a] = array[a+1];
                array[a+1] = swap ;
            }
        }
    }
}

void printo(int array[], int size){
    for (int i = 0 ; i < size ; ++i){
        printf("%d ", array[i]);
    }
    printf("\n");
    }

int main (){
    int data[]= {80,40,20,76,11,35};
    int soze = sizeof (data)/ sizeof data[0];
    Bs (data,soze);
    printf("Sorted Array : \n");
    printo(data,soze);
    
}
