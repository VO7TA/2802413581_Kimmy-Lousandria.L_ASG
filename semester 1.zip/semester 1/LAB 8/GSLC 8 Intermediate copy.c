#include <stdio.h>

void swp(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int parti(int array[], int first, int last) {
    int pivot = array[last];
    int poin = (first - 1);

    for (int i = first; i < last; i++) {
        if (array[i] <= pivot) {
            poin++;
            swp(&array[poin], &array[i]);
        }
    }

    swp(&array[poin + 1], &array[last]);
    return (poin + 1);
}

void QS(int array[], int first, int last) {
    if (first < last) {
        int phy = parti(array, first, last);
        QS(array, first, phy - 1);
        QS(array, phy + 1, last);
    }
}

void printar(int array[], int size) {
    for (int p = 0; p < size; ++p) {
        printf("%d ", array[p]);
    }
    printf("\n");
}

int main(void) {
    int data[] = {80, 40, 20, 76, 11, 35};
    int soze = sizeof(data) / sizeof(data[0]);

    QS(data, 0, soze - 1);
    printf("Sorted array:\n");
    printar(data, soze);

    return 0;
}
