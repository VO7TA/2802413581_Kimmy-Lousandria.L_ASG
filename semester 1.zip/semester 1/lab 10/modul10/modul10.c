#include <stdio.h>
#include <string.h>

struct Product {
    char name[20];
    int cost;
    char category;
    union {
        struct {
            char meat_type;
            int expiration_datemonth;
            char expiration_dateyear[11];
        } meats;
        struct {
            char produce_type;
            char date_received[11];
        } produce;
        struct {
            int expiration_datemonth;
            char expiration_dateyear[11];
        } dairy;
        struct {
            int expiration_datemonth;
            char expiration_dateyear[11];
            int aisle_num;
            char aisle_side;
        } canned;
        struct {
            char category_type;
            int aisle_num;
            char aisle_side;
        } nonfoods;
    } extra_data;
};
const char* month_string(int month){
    switch (month){
        case 1: return "Januari";
        case 2: return "Februari";
        case 3: return "Maret";
        case 4: return "April";
        case 5: return "Mei";
        case 6: return "Juni";
        case 7: return "Juli";
        case 8: return "Agustus";
        case 9: return "September";
        case 10: return "Oktober";
        case 11: return "November";
        case 12: return "Desember";
        default: return "Invalid month";
    }
}

void scan_product(struct Product *p) {
    scanf("%19s %d%c", p->name, &p->cost,&p->category);getchar();

    switch (p->category) {
        case 'M':
            scanf(" %c %d %10s ", &p->extra_data.meats.meat_type,
            &p->extra_data.meats.expiration_datemonth,p->extra_data.meats.expiration_dateyear);getchar();
            break;
        case 'P':
            scanf(" %c %10s ", &p->extra_data.produce.produce_type,
             p->extra_data.produce.date_received);getchar();
        case 'D':
            scanf(" %d %10s", &p->extra_data.dairy.expiration_datemonth, 
            p->extra_data.dairy.expiration_dateyear);getchar();
            break;
        case 'C':
            scanf(" %d %10s %d%c", &p->extra_data.canned.expiration_datemonth,
            p->extra_data.canned.expiration_dateyear,&p->extra_data.canned.aisle_num,
            &p->extra_data.canned.aisle_side);getchar();
            break;
        case 'N':
            scanf(" %c %d %c ", &p->extra_data.nonfoods.category_type, 
            &p->extra_data.nonfoods.aisle_num,&p->extra_data.nonfoods.aisle_side);getchar();
            break;
    }
}

void print_product(struct Product p) {
    printf("The %s cost %d cents,", p.name, p.cost);
    

    switch (p.category) {
        case 'M':
            printf("The Meat type %c expires in %s of %s\n ", p.extra_data.meats.meat_type,
            month_string(p.extra_data.meats.expiration_datemonth),p.extra_data.meats.expiration_dateyear);
            break;
        case 'P':
            printf("the produce type %c and date received %s\n", p.extra_data.produce.produce_type,p.extra_data.produce.date_received);
            break;
        case 'D':
            printf("expires in  %s of %s\n", month_string(p.extra_data.dairy.expiration_datemonth),p.extra_data.dairy.expiration_dateyear);
            break;
        case 'C':
            printf("expires in  %s of %s, and displayed in asle %d%c.\n", month_string(p.extra_data.canned.expiration_datemonth), 
            p.extra_data.canned.expiration_dateyear,
            p.extra_data.canned.aisle_num,
            p.extra_data.canned.aisle_side);
            break;
        case 'N':
            printf("category type: %c Aisle number %d Aisle side: %c", p.extra_data.nonfoods.category_type,
            p.extra_data.nonfoods.aisle_num,p.extra_data.nonfoods.aisle_side );
            break;
    }
}

int main() {
    struct Product prodak;
    scan_product(&prodak);
    print_product(prodak);
    return 0;
}