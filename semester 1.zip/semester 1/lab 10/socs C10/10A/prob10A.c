#include <stdio.h>
#include <string.h>



typedef struct{
    char kpendek[51];
    char kasli[51];
}file;

int main() {
     file f[100];
    int t, tc;
    char sentence[1000];

    FILE *p = fopen("testdata.in", "r");

 
    fscanf(p, "%d\n", &t);


    for (int i = 0; i < t; i++) {
        fscanf(p, "%[^#]#%[^\n]\n", f[i].kpendek, f[i].kasli);
    }

  
    fscanf(p, "%d\n", &tc);

    for (int Ycase = 0; Ycase < tc; Ycase++) {
        fgets(sentence, 1000, p);
        sentence[strcspn(sentence, "\n")] = '\0'; 

        char *token = strtok(sentence, " ");
        char hasil[1000] = "";

        while (token != NULL) {


            int fz = 0;
  
            for (int i = 0; i < t; i++) {
                if (strcmp(token, f[i].kpendek) == 0) {
                    strcat(hasil, f[i].kasli);
                    fz = 1;
                    break;
                }
            }

            if (!fz) {
                strcat(hasil, token);
            }


            token = strtok(NULL, " ");
            if (token != NULL) {
                strcat(hasil, " ");
            }
        }

        printf("Case #%d:\n%s\n", Ycase + 1, hasil);
    }

    fclose(p);

    return 0;
}

