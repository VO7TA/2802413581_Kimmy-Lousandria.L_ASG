#include<stdio.h>

int fpb(int a, int b){
	while(b!=0){
		int temp=b;
		b=a%b;
		a=temp;
	}
	return a;
}

int gcd(int a[], int n){
	int result=a[0];
	for(int i=1;i<n;i++){
		result=fpb(result, a[i]);
		if(result==1){
			break;
		}
	}
	return result;
}

int main(){
	
	int Tcase;
	
	scanf("%d", &Tcase);
	
	for(int i=0;i<Tcase;i++){
		
		int z;
		
		scanf("%d", &z);
		
		int arr[z];
		
		for(int j=0;j<z;j++){
			scanf("%d", &arr[j]);
		}
		int result=gcd(arr, z);
		printf("Case #%d: %d\n", i+1, result);
		
	}
	
	return 0;
}
