#include <stdio.h>
#include <string.h>

typedef struct {
    char nametitle[1000];
    char nameartist[1000];
    int Count;
} yt;

void bsort(yt videos[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {

            if (videos[j].Count < videos[j + 1].Count){
                yt temp = videos[j];
                videos[j] = videos[j + 1];
                videos[j + 1] = temp;

            } else if (videos[j].Count == videos[j + 1].Count ){
                if (strcmp(videos[j].nametitle, videos[j + 1].nametitle) > 0) {
                yt temp = videos[j];
                videos[j] = videos[j + 1];
                videos[j + 1] = temp;
             }
            } 
              
        }
    }
    for (int i = 0; i < n; i++) {
        printf("%s by %s - %d\n", videos[i].nametitle, videos[i].nameartist, videos[i].Count);
    }
}

int main() {
    FILE *p = fopen("testdata.in", "r");
    
    yt videos [100];
    int count = 0;
    while (fscanf(p, "%[^#]#%[^#]#%d\n", videos[count].nametitle, videos[count].nameartist, &videos[count].Count) != EOF) {
        count++;
    }
    

    fclose(p); 

    bsort(videos, count);

    
    

    return 0;
}
