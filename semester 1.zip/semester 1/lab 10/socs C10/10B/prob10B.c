#include<stdio.h>
#include<string.h>

int main(){
	
	int z, Tcase;
	
	FILE *p=fopen("testdata.in", "r");
	
	fscanf(p, "%d\n", &z);
	
		char nim[z][11], siswa[z][21];
	
	for(int i=0;i<z;i++){
		fscanf(p, "%[^ ] %[^\n]\n", nim[i], siswa[i]);
	}
	
	fscanf(p, "%d\n", &Tcase);
	
	char S[11];
	
	
	for(int i=0;i<Tcase;i++){
		int check=0;
		fscanf(p, "%[^\n]\n", S);
		printf("Case #%d: ", i+1);
		for(int j=0;j<z;j++){
			if(strcmp(S, nim[j])==0){
				printf("%s\n", siswa[j]);
				check=1;
				break;
			}
		}
		if(check==0){
			printf("N/A\n");
		}
	}
	
	return 0;
}
