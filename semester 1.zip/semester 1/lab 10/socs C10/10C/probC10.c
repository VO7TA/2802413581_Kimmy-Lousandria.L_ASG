#include <stdio.h>
#include <string.h>

typedef struct  {
    char name [50];
    int numberP;
}plants;

void bsort(plants z[], int n){

    for ( int a = 0 ; a < n-1 ; a++){
        for( int j = 0 ; j < n - a - 1 ; j++){
            if ( strcmp( z[j].name, z[j+1].name ) > 0 ) {
                plants temp = z[j];
                z[j]= z[j+1];
                z[j+1]= temp;
            }
        }
    }
}
    int main (){
        FILE* p = fopen("testdata.in","r");
        if ( p == NULL ){
            printf("error");
            return 1 ; 
        }
    int a;
    fscanf(p, "%d",&a);

    plants z[a];
    
    for ( int i = 0; i < a ; i++){
        fscanf(p , "%d#%[^\n]", &z[i].numberP,z[i].name);
    }
    fclose(p);

    bsort(z,a);
    for ( int i = 0; i < a ; i++){
        printf("%d %s\n", z[i].numberP,z[i].name);
    }
    return 0;
    }

