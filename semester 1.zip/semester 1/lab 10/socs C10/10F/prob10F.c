#include <stdio.h>

int main (){

    char temenJ[101];

    scanf("%[^\n]", temenJ);
    printf("Congrats \"%s\" for joining the CS department at BINUS.\n",temenJ);

    return 0;
}