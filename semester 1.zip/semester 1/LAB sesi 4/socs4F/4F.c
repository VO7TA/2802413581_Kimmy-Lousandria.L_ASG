#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    char kuy[10001];
    int i;

    fgets(kuy, sizeof(kuy), stdin);

    for (i = 0; kuy[i] != '\0'; i++) {
        if (isalpha(kuy[i])) {
        kuy[i] = toupper(kuy[i]);
            switch (kuy[i]) {
                case 'I': kuy[i] = '1'; break;
                case 'R': kuy[i] = '2'; break;
                case 'E': kuy[i] = '3'; break;
                case 'A': kuy[i] = '4'; break;
                case 'S': kuy[i] = '5'; break;
                case 'G': kuy[i] = '6'; break;
                case 'T': kuy[i] = '7'; break;
                case 'B': kuy[i] = '8'; break;
                case 'P': kuy[i] = '9'; break;
                case 'O': kuy[i] = '0'; break;
            }
        }
    }

    printf("%s", kuy);
    return 0;
}

//terima kasih pak alvin
