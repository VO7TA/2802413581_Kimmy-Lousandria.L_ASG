#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main (){
    
    int a, ab=0;
    char S[1001];
    
    scanf("%d", &a);
    
    for(int i=1;i<=a;i++){
        scanf("%s", S);
        
        while(S[ab]!='\0'){
            if(islower(S[ab])){
                S[ab]=toupper(S[ab]);
            }
            else if(isupper(S[ab])){
                S[ab]=tolower(S[ab]);
            }
            ab++;
        }
        ab=0;
        
        int ysk = strlen(S);

        for(int io=0; io < ysk/2 ; io++){
            char av= S[io];
            S[io]=S[ysk-io-1];
            S[ysk-io-1]=av;
        
        }
        printf("Case #%d: %s\n", i, S);
}
    return 0;
}

