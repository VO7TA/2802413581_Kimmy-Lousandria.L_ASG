#include <stdio.h>

int main() {
    
    int ey = 200;
    double bonus , gross = 0.09;
    
    printf("Enter sales in dollar (-1 to end): ");
    scanf("%lf", &bonus );
    
    while( bonus != -1) {
        double gaji = (bonus*gross)+ey;
        printf("Salary is :$%.2lf\n",gaji);
        
        printf("Enter sales in dollar (-1 to end): ");
        scanf("%lf", &bonus );
    }
    
    

    return 0;
}
