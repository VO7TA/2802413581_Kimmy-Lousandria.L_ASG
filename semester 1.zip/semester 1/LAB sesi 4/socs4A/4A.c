#include <stdio.h>

int main() {
    int i, t, m;
    char nama_item [3][10] = {"Daging", "Sayur", "Telur"};
    int harga[4];
    int order[3] = {0, 1, 2};
    int h, j, x;

    scanf("%d %d %d", &i, &t, &m);

    harga[0] = i;
    harga[1] = t;
    harga[2] = m;

    for (h = 0; h < 2; h++) {
        for (j= 0; j < 2 - h; j++) {
            if (harga[order[j]] < harga[order[j + 1]]) {
                x = order[j];
                order[j] = order[j + 1];
                order[j + 1] = x;
            }
        }
    }

    for (i = 0; i < 3; i++) {
        printf("%s\n", nama_item[order[i]]);
    }

    return 0;
}
