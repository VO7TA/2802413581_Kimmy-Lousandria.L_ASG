#include <stdio.h>
//X
//int main() {
//    
//    int w;
//    int i;
//    int j;
//    scanf("%d",&w);
//    
//    for (i = 0; i < w; i++) {
//        for ( j = 0; j < w; j++) {
//            if (j == i || j == (w - 1 - i)){
//                printf("*");
//            } else {
//                printf(" ");
//            }
//        }
//        printf("\n");
//    }
//    return 0;
//}


//segitiga

int main (){
    int it;
    scanf("%d",&it);
    int xi,yi ;
    for (xi= 1 ; xi <= it; xi++){
        for (yi = 1; yi <= xi;yi++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
    }

