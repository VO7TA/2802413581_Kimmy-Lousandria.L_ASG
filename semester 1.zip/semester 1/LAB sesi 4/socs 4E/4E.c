#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void) {
    
    int bil_bul;
    char bey [501];
    
    scanf("%d",&bil_bul);
    
    for(int x = 1; x <= bil_bul ; x++){
        scanf("%s",bey);
        char boy[501];
        
        int ysk = strlen(bey);
        int answ = 1;
        
        for(int a = 0 ; a < ysk/2; a++){
            if(bey[a] != bey[ysk - a - 1]) {
                answ = 0;
                break;
            }
        }
        
        
        if(answ==1){
            printf("Case #%d: Yay, it's a palindrome\n", x);
        
        }
        else {
            printf("Case #%d: Nah, it's not a palindrome\n", x);
        }
        
    }
    return 0;
}
