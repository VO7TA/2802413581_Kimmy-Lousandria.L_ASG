#include <stdio.h>

int main (){
    int it;
    scanf("%d",&it);
    int xi,yi ;
    for (xi= 1 ; xi <= it; xi++){
        for (yi = 1; yi <= xi;yi++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
    }

