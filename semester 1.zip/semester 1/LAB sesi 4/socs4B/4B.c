
#include <stdio.h>

int main() {
        
        int q, x;
        
        int hasil_akhir = 0;

        scanf("%d", &q);
        
        for(int i=1;i<=q;i++){
            scanf("%d", &x);
            
            int a[x][x];
            
            for(int k=0;k<x;k++){
                for(int l=0;l<x;l++){
                    scanf("%d", &a[k][l]);
                
                }
                
            }
            
        printf("Case #%d:", i);
        
            
        
            for(int k=0;k<x;k++){
                for(int l=0;l<x;l++){
                
                    hasil_akhir=hasil_akhir+a[l][k];
                                
                }
                
                    printf(" %d", hasil_akhir);
                    hasil_akhir=0;
                    
        }
            
                    printf("\n");
                    
                }
    return 0;
}
