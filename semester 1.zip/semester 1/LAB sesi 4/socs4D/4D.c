#include <stdio.h>

int main(void) {
    
    int ac, bc, cc, fc, gc, hc;
    
    scanf("%d %d %d", &ac, &bc, &cc);
    
    int ay[ac][bc];
    for (int dc= 0; dc < ac; dc++) {
        for (int ec = 0; ec < bc; ec++) {
            ay[dc][ec] = 0;
        }
    }
    
    for (int dc = 0; dc < cc; dc++) {
       scanf("%d %d %d", &fc, &gc, &hc);
        ay[fc][gc] = hc;
    }
    
    for (int dc = 0; dc < ac; dc++) {
        for (int ec = 0; ec < bc; ec++) {
            printf("%d", ay[dc][ec]);
            if (ec < bc - 1) {
                printf(" ");
            }
        }
        printf("\n");
    }
    
 return 0;
}
