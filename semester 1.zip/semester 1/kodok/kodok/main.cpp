#include <iostream>

using namespace std;

int main() {
    int jumlah, harga, kode;
    
    cout<<"DAFTAR TIKET SEPAK BOLA" << endl;
    cout<< "241101.EKONOMI 1" << endl;
    cout<< "241102.EKONOMI 2" << endl;
    cout<< "241103.EKONOMI 3" << endl;
    cout<< "241104.EKONOMI 4" << endl;
    cout<< "241105.EKONOMI 5" << endl;
    cout<< "2411001.VVIP 1" << endl;
    cout<< "2411002.VVIP 2" << endl;
    cout<< "2411003.VVIP 3" << endl;
    cout<< "============================================ " << endl;
    
    cout << "masukan kode : " ;
    cin >>kode;
    
    if(kode==241101){
        harga=200000;
    }
    if(kode==241102){
        harga=250000;
    }
    if(kode==241103){
        harga=300000;
    }
    if(kode==241104){
        harga=350000;
    }
    if(kode==241105){
        harga=400000;
    }
    if(kode==2411001){
        harga=1500000;
    }
    if(kode==2411002){
        harga=2500000;
    }
    if(kode==2411003){
        harga=3500000;
    }
    
    switch(kode){
        case 241101:
            cout<<"Harga Tiket Rp.200,000/orang" << endl;
            break;
        case 241102:
            cout<<"Harga Tiket Rp.250,000/orang" << endl;
            break;
        case 241103:
            cout<<"Harga Tiket Rp.300,000/orang" << endl;
            break;
        case 241104:
            cout<<"Harga Tiket Rp.350,000/orang" << endl;
            break;
        case 241105:
            cout<<"Harga Tiket Rp.400,000/orang" << endl;
            break;
        case 2411001:
            cout<<"Harga Tiket Rp.1.500,000/orang" << endl;
            break;
        case 2411002:
            cout<<"Harga Tiket Rp.2.500,000/orang" << endl;
            break;
        case 2411003:
            cout<<"Harga Tiket Rp.3.500,000/orang" << endl;
            break;
        default :
            cout<<"KODE YANG ANDA MASUKAN SALAH" << endl;
    }
    
    cout<< "MASUKAN JUMLAH ; ";
    cin>>jumlah;
    
    if(jumlah>0){
        cout<< "Total bayar : Rp"<<jumlah*harga;
    }
    
        
    }
