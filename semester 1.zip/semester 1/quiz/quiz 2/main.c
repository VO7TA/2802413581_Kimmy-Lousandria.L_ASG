#include <stdio.h>

int main (void){
    char judul;
    char author;
    char publikasi;
    
    
    
    
    printf("Insert book title : \n");
    scanf("%c", &judul);
    getchar();
    printf("Insert book author : \n");
    scanf("%c", &author);
    getchar();
    printf("Insert book published : \n");
    scanf("%c", &publikasi);
    getchar();
                   
            printf("Insert book title : \n");
            scanf("%c", &judul);
            getchar();
            printf("Insert book author : \n");
            scanf("%c", &author);
            getchar();
            printf("Insert book published : \n");
            scanf("%c", &publikasi);
            getchar();
    
                        printf("Insert book title : \n");
                        scanf("%c", &judul);
                        getchar();
                        printf("Insert book author : \n");
                        scanf("%c", &author);
                        getchar();
                        printf("Insert book published : \n");
                        scanf("%c", &publikasi);
                        getchar();
    
    
                                    printf("Insert book title : \n");
                                    scanf("%c", &judul);
                                    getchar();
                                    printf("Insert book author : \n");
                                    scanf("%c", &author);
                                    getchar();
                                    printf("Insert book published : \n");
                                    scanf("%c", &publikasi);
                                    getchar();
    return 0;
}

