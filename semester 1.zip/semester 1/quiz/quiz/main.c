#include <stdio.h>
#include <string.h>

int main (void){
    
    int stock1= 5,stock2= 10,stock3= 1,stock4= 3,stock5= 15,stock6=20,stock7=1,stock8= 5,stock9= 10 ,stock10= 10;
    int totalsub_1=0,totalsub_2=0,totalsub_3=0,totalsub_4=0,totalsub_5=0,totalsub_6=0,totalsub_7=0,totalsub_8=0,totalsub_9=0,totalsub_10=0;
    int count_1=0,count_2=0,count_3=0,count_4=0,count_5=0,count_6=0,count_7=0,count_8=0,count_9=0,count_10=0;
    int total=0;
    int item;
    int totem;
    char mbayar;
    puts("No. |Item's name      |Stock|Price    |Count|Sub Total");
    printf("1.  |Panda mi         |%-*d |5000     |%-*d|%-*d\n",4,stock1,5,count_1,5,totalsub_1);
    printf("2.  |Panda milk       |%-*d |7500     |%-*d|%-*d\n",4,stock2,5,count_2,5,totalsub_2);
    printf("3.  |Yellow Band      |%-*d |3000     |%-*d|%-*d\n",4,stock3,5,count_3,5,totalsub_3);
    printf("4.  |Healthy Olive Oil|%-*d |50000    |%-*d|%-*d\n",4,stock4,5,count_4,5,totalsub_4);
    printf("5.  |Three Panda Rice |%-*d |70000    |%-*d|%-*d\n",4,stock5,5,count_5,5,totalsub_5);
    printf("6.  |Chicken Egg      |%-*d |11000    |%-*d|%-*d\n",4,stock6,5,count_6,5,totalsub_6);
    printf("7.  |PAnda Soy Sauce  |%-*d |12000    |%-*d|%-*d\n",4,stock7,5,count_7,5,totalsub_7);
    printf("8.  |Your Salt        |%-*d |3000     |%-*d|%-*d\n",4,stock8,5,count_8,5,totalsub_8);
    printf("9.  |My Sugar         |%-*d |21000    |%-*d|%-*d\n",4,stock9,5,count_9,5,totalsub_9);
    printf("10. |Baby soap        |%-*d |3000     |%-*d|%-*d\n",4,stock10,5,count_10,5,totalsub_10);
    printf("Total : %d\n", total);
    
    
    do{
        printf("Input item that you want [1-10] :");
        scanf("%d", &item);
    } while (item < 1 || item > 10);
    switch (item){
            
        case 1:
            do{
                printf("How many pack of Panda mi that you wan [0-5]:");
                            scanf("%d",&totem);
            } while ( totem <1 || totem >10 );
            
            do {
                printf("Do you want to pay the bill? [y|n] : ");
                scanf(" %c",&mbayar);
                
            }while ( mbayar != 'y' || mbayar != 'n' );
            if (mbayar == 'n')
            {
                
                
            }
    }
}
