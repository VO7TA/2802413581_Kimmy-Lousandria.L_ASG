#include <stdio.h>

int main() {
    char *menu_items[] = {"Boneless Wings", "Classic Wings", "Garlic Fries", "Soft Drink"};
    int prices[] = {45000, 55000, 30000, 18000};
    int quantities[4] = {0};
    int total = 0;
    int ordered_drink = 0;

    printf("Welcome to Wingstop Indonesia!\n\n");

    printf("Menu:\n");
    for (int i = 0; i < 4; i++) {
        printf("%d. %s - Rp%d\n", i + 1, menu_items[i], prices[i]);
    }
    printf("\n");

    int choice;
    do {
        printf("Enter item number (1-4) or 0 to finish: ");
        scanf("%d", &choice);

        if (choice > 0 && choice <= 4) {
            printf("Enter quantity for %s: ", menu_items[choice - 1]);
            scanf("%d", &quantities[choice - 1]);

            if (choice == 4) {  
                ordered_drink = 1;
            }
        } else if (choice != 0) {
            printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 0);

    for (int i = 0; i < 4; i++) {
        total += prices[i] * quantities[i];
    }

    if (total > 100000) {
        int discount = total * 0.1;
        printf("10%% discount applied: -Rp%d\n", discount);
        total -= discount;
    }

    if (ordered_drink) {
        int extra_discount = total * 0.05;
        printf("5%% extra discount for ordering a drink: -Rp%d\n", extra_discount);
        total -= extra_discount;
    }

    printf("\nOrder Summary:\n");
    for (int i = 0; i < 4; i++) {
        if (quantities[i] > 0) {
            printf("%s x%d: Rp%d\n", menu_items[i], quantities[i], prices[i] * quantities[i]);
        }
    }

    printf("\nTotal bill: Rp%d\n", total);

    return 0;
}


/*
 1. Array digunakan dalam metode menu karena array adalah yg terbaik dalam menyimpan variable dalam bentuk string array. Dengan menggunakan array kita tidak perlu menyimpan menu kedalam variable. sehingga menjadi lebih effisien
 2. loop digunakan untuk memesan menu agar pembeli dapat diberikan opsi untuk membeli tambahan menu lain
 3. if else untuk diskon digunakan karena diskon adalah suatu hal yang membutuhkan syarat yg lebih dari 1 karena dia(diskon) memerlukan syart yg lebih dari satu maka ini akan sangat mempermudah apabila menggunakan if else
 4. Jika hanya memesan soft drink maka jika orang tersebut membeli jumlah  <= 6 buah sofdrink maka dia hanya mendapat diskon potongan 5% untuk softdrink saja dan belum mendapat diskon 10%. sedangkan jika diatas 6 buah maka dia akan mendapat diskon 5% untuk sofdrink dan ditambah 10%.
 */
