#include <stdio.h>

int fib0(int n, int *hitung){
    *hitung = *hitung+1;
    
    if(n==0){
        return 0;
    
    }
    else if(n==1){
        return 1;
        
    }
    else {
        return fib0(n-2, hitung)+fib0(n-1, hitung);
            
    }
}

int main(){
    
    int Tcase, n;
    int hitung=0;
    
    scanf("%d", &Tcase);
    
    for(int i=0;i < Tcase;i++){
        scanf("%d", &n);
        fib0(n, &hitung);
        printf("Case #%d: %d\n", i+1, hitung);
        hitung=0;
    }
    return 0;
}
