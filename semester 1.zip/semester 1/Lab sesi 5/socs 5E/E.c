#include <stdio.h>

int main() {
    int fnol, ftu, n;
    scanf("%d %d", &fnol, &ftu);
    scanf("%d", &n);

    int fib0[n + 1];
    fib0[0] = fnol;
    fib0[1] = ftu;

    for (int i = 2; i <= n; i++) {
        fib0[i] = fib0[i - 1] + fib0[i - 2];
    }

    printf("%d\n", fib0[n]);
    return 0;
}
