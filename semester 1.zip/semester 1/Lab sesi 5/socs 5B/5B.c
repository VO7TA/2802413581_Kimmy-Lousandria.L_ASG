#include <stdio.h>


int c(char si[]){
    int d=0;
    
    for(int i=0;si[i]!='\0';i++){
        int sm=0;
        for(int j=0;j<i;j++){
            if(si[j]==si[i]){
                sm=1;
                break;
            }
        }
        if(sm==0){
            d++;
        }
    }
    return d;
}


int main(){
    
    int Tcase;
    char F[100000];
    
    scanf("%d", &Tcase);
    
    for(int i=0;i<Tcase;i++){
        scanf("%s", F);
        
        int result=c(F);
        
        printf("Case #%d: ", i+1);
    
        if(result%2==0){
            printf("Yay\n");
        }
        else {
            printf("Ewwww\n");
        }
        result=0;
    }
    
    return 0;
}
