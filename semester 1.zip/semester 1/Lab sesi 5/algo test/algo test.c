#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char username [100];
    char password [15][100], pass [100];
    char email [50];
    char ordinal [11][3]= {"st","nd","rd","th","th","th","th","th","th","th"};
    int user,status;
    
    do {
        printf("input max input [3-10]:");
        scanf("%d",&user); fflush(stdin);
    }  while ( user < 3 || user > 10);
    
    for ( int w = 0 ; w < user ; w++){
    }
        do {
            printf("Input the %d%s username [must be uniq]:\n",w+1,ordinal[w]);
            scanf("%s",username);
            
            status = 1;
            
            for (int j = 0; j<w ; j++){
                if (strcmp(&username[j],&username [w]) == 0) status= 0;
            
            } while (status == 0);
        
        
        return 0;
    }
}
