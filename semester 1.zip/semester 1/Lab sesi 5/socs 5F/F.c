#include <stdio.h>

int main() {
    int Tcase;
    scanf("%d", &Tcase);
    
    for (int i = 0; i < Tcase; i++) {
        int Ni, Xi, Yi;
        scanf("%d %d %d", &Ni, &Xi, &Yi);
        int fib0[30];
        fib0[0] = Xi;
        fib0[1] = Yi;

        for (int j = 2; j <= Ni; j++) {
            fib0[j] = fib0[j - 1] - fib0[j - 2];
        }

        printf("Case #%d: %d\n", i + 1, fib0[Ni]);
    }

    return 0;
}
