#include <stdio.h>

int main() {
    int Tcase, N;
    int dibutuhkan[100], dimiliki[100];
    
    scanf("%d", &Tcase);
            for(int ii = 1; ii <= Tcase; ii++) {
                    scanf("%d", &N);
        
                for(int ii = 0; ii < N; ii++) {
                    scanf("%d", &dibutuhkan[ii]);
        }
        
        for(int ii = 0; ii < N; ii++) {
            scanf("%d", &dimiliki[ii]);
        }
        
        printf("Case #%d:", ii);
        for(int ii = 0; ii < N; ii++) {
            printf(" %d", dibutuhkan[ii] - dimiliki[ii]);
        }
        printf("\n");
    }
    
    return 0;
}
