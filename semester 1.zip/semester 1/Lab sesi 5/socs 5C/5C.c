#include <stdio.h>
#include <string.h>

void DIB_string ( int s, char snol [], char stu[], char resil []){
    if (s == 0) {
        strcpy ( resil,snol);
    }else if ( s == 1){
        strcpy ( resil, stu);
    }else {
        char a[1000];char b[1000];
        DIB_string(s - 1, snol, stu, a);
        DIB_string(s - 2, snol, stu, b);
        strcpy(resil, a);
        strcat(resil, b);
            }
        }

int main(){
    int Tcase,s;
    char snol[10],stu[10],resil[1001];
   
    scanf("%d", &Tcase);
    for (int i = 1; i <= Tcase; i++) {
            scanf("%d %s %s", &s, snol, stu);
        
        
        DIB_string(s,snol,stu,resil);
        
        printf("Case #%d: %s\n",i,resil);
    }
    return 0;
}
