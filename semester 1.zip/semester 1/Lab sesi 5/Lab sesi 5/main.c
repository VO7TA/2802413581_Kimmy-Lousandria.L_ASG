#include <stdio.h>
#include <string.h>

int main(){
    
    int bey[2];
    int i;
    
    for ( i=0 ; i <= 1; i++){
        printf(" masukkan angka ke %d : ", i + 1);
        scanf("%d",&bey[i]);
    }
    i=0;
    int k = 0;
    if ( bey[i]>bey[i+1]){
        printf("Angka terbesar adalah angka ke 1 yaitu : %d\n", bey[i]);
    }else printf("Angka terbesar adalah angka ke 2 yaitu : %d\n", bey [i+1]);

    return 0;
}

    

