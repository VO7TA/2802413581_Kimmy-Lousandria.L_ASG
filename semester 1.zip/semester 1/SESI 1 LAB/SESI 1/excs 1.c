#include <stdio.h>

int main()
{
    
    int a = 15;
    
        scanf("%d",&a);
            printf("Selamat ulang tahun yang ke %d yaaa!",a);
    
}
