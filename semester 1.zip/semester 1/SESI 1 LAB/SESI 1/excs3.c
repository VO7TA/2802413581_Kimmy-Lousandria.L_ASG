#include <stdio.h>

int main()
{
    int a;
    int b;
    
        printf("Enter first integer : ");
            scanf("%d",&a);
        
        printf("Enter seco45nd integer:");
            scanf("%d",&b);
    
    int sum = a + b ;
    printf("Sum is %d",sum);

    return 0;
}

