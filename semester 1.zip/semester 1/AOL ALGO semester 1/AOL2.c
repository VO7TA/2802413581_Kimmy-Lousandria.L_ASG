#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FILENAME "inventory2.bin"

struct Item {
    char name[50];
    float price;
};

struct Supplier {
    char name[50];
    char phone[15];
    int id;
};

struct Inventory {
    int item_id;
    int supplier_id;
    int quantity;
    struct Item item;
    struct Supplier supplier;
    float sales;
};

void insertRecord() {
    FILE *fp;
    struct Inventory inv;
    
    fp = fopen(FILENAME, "ab");
    if(fp == NULL) {
        printf("Error opening file!\n");
        return;
    }
    
    printf("Enter Item ID: ");
    scanf("%d", &inv.item_id);getchar();
    printf("Enter Item Name: ");
    scanf(" %[^\n]s", inv.item.name);getchar();
    printf("Enter Item Price: ");
    scanf("%f", &inv.item.price);getchar();
    printf("Enter Supplier ID: ");
    scanf("%d", &inv.supplier_id);getchar();
    printf("Enter Supplier Name: ");
    scanf(" %[^\n]s", inv.supplier.name);getchar();
    printf("Enter Supplier Phone: ");
    scanf(" %[^\n]s", inv.supplier.phone);getchar();
    printf("Enter Quantity: ");
    scanf("%d", &inv.quantity);getchar();
    
    inv.sales = inv.item.price * inv.quantity;
    
    fwrite(&inv, sizeof(struct Inventory), 1, fp);
    fclose(fp);
    printf("Record inserted successfully!\n");
}

void showRecord() {
    FILE *fp;
    struct Inventory inv;
    float grandTotal = 0;
    int totalQuantity = 0;
    
    fp = fopen(FILENAME, "rb");
    if(fp == NULL) {
        printf("Error opening file!\n");
        return;
    }
    
    printf("\nITEM ID\tSUPPLIER ID\tITEM NAME\tPRICE\tQUANTITY\tSALES\n");
    printf("---------------------------------------------------------------------\n");
    
    while(fread(&inv, sizeof(struct Inventory), 1, fp)) {
        printf("A%d\tS%d\t\t%s\t\t%.2f\t %d\t\t%.2f\n", 
               inv.item_id, inv.supplier_id, inv.item.name, 
               inv.item.price, inv.quantity, inv.sales);
        grandTotal += inv.sales;
        totalQuantity += inv.quantity;
    }
    
    printf("\nGrand Total: %.2f\n", grandTotal);
    printf("Total Stock Quantity: %d\n", totalQuantity);
    
    fclose(fp);
}

void selectData() {
    FILE *fp;
    struct Inventory inv;
    int search_id;
    
    printf("Enter Item ID to search: ");
    scanf("%d", &search_id);
    
    fp = fopen(FILENAME, "rb");
    if(fp == NULL) {
        printf("Error opening file!\n");
        return;
    }
    
    while(fread(&inv, sizeof(struct Inventory), 1, fp)) {
        if(inv.item_id == search_id) {
            printf("\nItem found!\n");
            printf("Item Name: %s\n", inv.item.name);
            printf("Price: %.2f\n", inv.item.price);
            printf("Quantity: %d\n", inv.quantity);
            printf("Supplier Name: %s\n", inv.supplier.name);
            printf("Supplier Phone: %s\n", inv.supplier.phone);
            fclose(fp);
            return;
        }
    }
    
    printf("Item not found!\n");
    fclose(fp);
}

void deleteRecord() {
    FILE *fp, *temp;
    struct Inventory inv;
    int del_id;
    
    printf("Enter Item ID to delete: ");
    scanf("%d", &del_id);
    
    fp = fopen(FILENAME, "rb");
    temp = fopen("temp.bin", "wb");
    
    if(fp == NULL || temp == NULL) {
        printf("Error opening file!\n");
        return;
    }
    
    while(fread(&inv, sizeof(struct Inventory), 1, fp)) {
        if(inv.item_id != del_id) {
            fwrite(&inv, sizeof(struct Inventory), 1, temp);
        }
    }
    
    fclose(fp);
    fclose(temp);
    remove(FILENAME);
    rename("temp.dat", FILENAME);
    printf("Record deleted successfully!\n");
}

void updateRecord() {
    FILE *fp, *temp;
    struct Inventory inv;
    int update_id;
    
    printf("Enter Item ID to update: ");
    scanf("%d", &update_id);
    
    fp = fopen(FILENAME, "rb");
    temp = fopen("temp.bin", "wb");
    
    if(fp == NULL || temp == NULL) {
        printf("Error opening file!\n");
        return;
    }
    
    while(fread(&inv, sizeof(struct Inventory), 1, fp)) {
        if(inv.item_id == update_id) {
            printf("Enter new quantity: ");
            scanf("%d", &inv.quantity);
            inv.sales = inv.item.price * inv.quantity;
        }
        fwrite(&inv, sizeof(struct Inventory), 1, temp);
    }
    
    fclose(fp);
    fclose(temp);
    remove(FILENAME);
    rename("temp.dat", FILENAME);
    printf("Record updated successfully!\n");
}

int main() {
    int choice;
    
    while(1) {
        printf("\nINVENTORY SYSTEM\n");
        printf("INVENTORY DATA MAIN MENU\n\n");
        printf("What do you want to do?\n");
        printf("1. Insert Record\n");
        printf("2. Show Record\n");
        printf("3. Select Data\n");
        printf("4. Delete Record\n");
        printf("5. Update Record\n");
        printf("6. Exit\n");
        printf("\nYour choice: ");
        scanf("%d", &choice);
        
        switch(choice) {
            case 1:
                insertRecord();
                break;
            case 2:
                showRecord();
                break;
            case 3:
                selectData();
                break;
            case 4:
                deleteRecord();
                break;
            case 5:
                updateRecord();
                break;
            case 6:
                printf("Thank you for using the system!\n");
                exit(0);
            default:
                printf("Invalid choice!\n");
        }
    }
    
    return 0;
}