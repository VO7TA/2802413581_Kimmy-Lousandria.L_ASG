#include <stdio.h>

int main(){
    
    char n1[100], n2[100];
    double f1,f2;
    int i1,i2;
    
    
        scanf("%s %lf %d %s %lf %d", n1, &f1, &i1, n2, &f2, &i2);
            
            printf("Name 1: %s\n", n1);
                printf("Height 1: %.2lf\n", f1);
                    printf("Age 1: %d\n", i1);
                    printf("Name 2: %s\n", n2);
                printf("Height 2: %.2lf\n", f2);
        printf("Age 2: %d\n", i2);
    
    return 0;
}
