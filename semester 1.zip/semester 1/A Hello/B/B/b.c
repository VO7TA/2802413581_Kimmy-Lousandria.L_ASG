
#include <stdio.h>

int main(){
    
    int a;
    char b[100];
    scanf("%s",b);
    scanf("%d",&a);
    
    printf("%s\n", b);
    printf("%d\n", a);
    
    return 0;
    
}
