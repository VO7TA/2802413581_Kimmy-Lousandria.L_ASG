
#include <stdio.h>

int main(){
    
    char nama [100];
    scanf("%s",nama);
    printf("%s-san\n",nama);
    
    return 0;
}
