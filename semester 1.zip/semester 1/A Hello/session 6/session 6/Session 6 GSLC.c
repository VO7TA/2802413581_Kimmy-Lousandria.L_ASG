#include <stdio.h>
int main(){
    float p = 10000;
    float bb = 6500;
    int h = 30;
    
        float pengeluaran = bb ;
        float sisa = p - bb ;
        float rata_rata = (float)bb/h ;

    printf("Total pengeluaran bulanan: $%.2f\n",pengeluaran);
    printf("Sisa dana setelah pengeluaran: $%.2f\n",sisa);
    printf("Rata-rata pengeluaran harian dalam sebulan: $%.2f\n",rata_rata);

    return 0;

}

