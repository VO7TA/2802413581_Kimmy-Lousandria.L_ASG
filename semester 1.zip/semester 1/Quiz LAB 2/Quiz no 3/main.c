#include <stdio.h>

int fibonacci( int n) {
    
    if ( n == 0)
        return 0;
    if ( n == 1)
        return 1;
    return fibonacci (n-1)+ fibonacci (n-2);
    
}
void bilanganNatural(int n, int *sum) {
    if (n == 0)
        return;
    bilanganNatural(n - 1, sum);
    printf("%d ", n);
    *sum += n;
}
int faktorial ( int n ){
    if (n == 0 || n == 1)
        return 1;
    return n * faktorial(n-1);
}

int permutasi (int n, int r){
    return faktorial(n)/faktorial (n-r);
}

int kombinasi(int n, int r){
    return faktorial(n)/ (faktorial(r)*faktorial (n-r));
}

int main (){
    int n,sum,r;
    
    puts("Serba-Serbi Rekursi");
    puts("===================");
    puts(" 1. Deret Fibonacci\n 2. Bilangan Natural \n 3. Permutasi\n 4. Kombinasi\n 5. Keluar");
    
    int Tcase;
    printf("Pilih>>  ");
    scanf("%d",&Tcase);
    
    switch (Tcase)
    {
        case 1:
            printf("Masukkan angka n : ");
            scanf("%d", &n);
            printf("Deret fibonacci : ");
            for (int i = 0 ; i<= n; i++){
                printf("%d ", fibonacci(i));
            }
            printf("\n");
            break;
            
        case 2:
            sum = 0;
            printf("Masukkan nilai N: ");
            scanf("%d", &n);
            puts("Bilangan Natural hingga: ");
            bilanganNatural(n,&sum);
            printf("\n Jumlah dari bilangan natural : %d",sum);
            break;
            
        case 3 :
            printf("Masukkan angka n :  ");
            scanf("%d", &n);
            printf("Masukkan angka r :  ");
            scanf("%d", &r);
            if (n > r && n > 0 && r > 0) {
                printf("%dP%d = %d\n", n, r, permutasi(n, r));
            } else {
                printf("Input tidak valid, coba lagi.\n");
            }
            break;
            
        case 4:
            printf("Masukkan angka n :  ");
            scanf("%d", &n);
            printf("Masukkan angka r :  ");
            scanf("%d", &r);
            if (n > r && n > 0 && r > 0) {
                printf("%dC%d = %d\n", n, r, kombinasi(n, r));
            } else {
                printf("Input tidak valid, coba lagi.\n");
            }
            break;
            
        case 5:
            printf("Anda telah keluar dari program, terima kasih:)\n");
            return 0;
            
        default:
            printf("Pilihan anda tidak valid, coba lagi.\n");
    }
    return 0;
}

