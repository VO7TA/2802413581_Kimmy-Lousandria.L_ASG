#include <stdio.h>

int main(){
    
    int a= 0,b = 0, pucuk = 2;
    
    puts("Menu Repetisi");
    puts(" 1. Membuat jajar genjang\n 2. Membuat Segitiga Prima \n");
    
    int Tcase;
    printf("Pilihan Menu : ");
    scanf("%d",&Tcase);
    
    switch (Tcase)
    {
        case 1:
            printf("Masukkan Tinggi Jajar genjang : ");
            scanf("%d" ,&a);
            printf("Masukkan  lebar Jajar genjang : ");
            scanf("%d",&b);
            
            for (int i = 0; i < b; i++) {
                   
                    for (int j = 0; j < i; j++) {
                        printf(" ");
                    }

                   
                    for (int k = 0; k < b; k++) {
                        printf("*");
                    }
                    printf("\n");
            }break;
            
        case 2:
                printf("Masukkan tinggi segitiga: ");
                scanf("%d", &a);

                for (int i = 1; i <= a; i++) {
                    for (int j = 0; j < i; j++) {
            
                        int Prima = 0;
                        
                        while (Prima == 0) {
                            Prima = 1;
                            for (int k = 2; k * k <= pucuk; k++) {
                                if (pucuk % k == 0) {
                                    Prima = 0;
                                    break;
                                }
                            }
                            if (Prima == 0)
                                pucuk++;
                        }
                        printf("%d ", pucuk);
                        pucuk++;
                    }
                    printf("\n");
                }
        default:
        printf("Pilihan anda tidak valid, coba lagi.\n");
                return 0;
            }
    }

    


