#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_LENGTH 1000

void reverseCharacters(char *sentence) {
    int length = strlen(sentence);
    
    printf("Reversed Sentence: ");
    for (int i = length - 1; i >= 0; i--) {
        putchar(sentence[i]);
    }
    printf("\n");
}

int countWords(char *sentence) {
    int count = 0;
    char *token = strtok(sentence, " ");
    while (token) {
        count++;
        token = strtok(NULL, " ");
    }
    return count;
}

int main() {
    char sentence[MAX_LENGTH];
    char choice[10];

    puts("Reverse Sentence :");
    puts("==================");
    printf("\n");
    
    do {
        do {
            printf("Input sentence [minimun 5 words]: ");
            fgets(sentence, MAX_LENGTH, stdin);
            sentence[strcspn(sentence, "\n")] = 0;
            
            char temp[MAX_LENGTH];
            strcpy(temp, sentence);
            int wordCount = countWords(temp);
            
            if (wordCount < 5) {
                printf("Error: Sentence must contain exactly 5 words bodo. Please try again.\n");
            } else {
                break;
            }
        } while (1);
        
        reverseCharacters(sentence);
        
        printf("Do you want to continue? (yes/no): ");
        fgets(choice, sizeof(choice), stdin);
        choice[strcspn(choice, "\n")] = 0;
        
    } while (strcasecmp(choice, "yes") == 0);
    
    printf("terima gaji.\n");
    return 0;
}
