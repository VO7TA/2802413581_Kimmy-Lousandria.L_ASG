#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define TABLE_SIZE 1007
#define MAX_TITLE 50
#define MIN_TITLE 5
#define MIN_PAGES 16
#define MAX_AUTHOR_LENGTH 30
#define MAX_ISBN_LENGTH 14



typedef struct book {
    char bookId[30];
    char title[MAX_TITLE];
    char author[30];
    char isbn[14];
    int pages;
    struct book* next;
} book;

book** hashTable;
int bookCounter;

void initializeHashTable() {
    hashTable = (book**)calloc(TABLE_SIZE, sizeof(book*));
    if (!hashTable) {
        printf("Memory allocation failed!\n");
        exit(1);
    }
}

void clearHashTable() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        book* temp = hashTable[i];
        while (temp) {
            book* next = temp->next;
            free(temp);
            temp = next;
        }
        hashTable[i] = NULL;
    }
}

int hashFunction(char* bookid) {
    int sum = 0;
    for (int i = 0; bookid[i] != '\0'; i++) {
        sum += bookid[i];
    }
    return sum % TABLE_SIZE;
}

void viewBooks() {
    int empty = 1;
    for (int i = 0; i < TABLE_SIZE; i++) {
        if (hashTable[i]) {
            empty = 0;
            book* temp = hashTable[i];
            puts("-----------------------------------------------------------------------------");
            puts("| Book ID      | Book Title          | Author          | ISBN          | Pages         |");
            puts("-----------------------------------------------------------------------------");
            while (temp) {
                
                printf("| %-10s | %-15s | %-15s | %-10s | %-10d\n", 
                        temp->bookId, temp->title, temp->author, temp->isbn, temp->pages);
                puts("-----------------------------------------------------------------------------");
                temp = temp->next;
            }
        }
    }
    if (empty) {
        printf("There is no book!\n");
    }
}

void insertBook() {
    char title[MAX_TITLE], author[MAX_AUTHOR_LENGTH], isbn[MAX_ISBN_LENGTH];
    int pages;

    int valid = 0;
while (!valid) {
    printf("Enter Book Title [5-50][Unique]: ");
    fgets(title, MAX_TITLE, stdin);
    title[strcspn(title, "\n")] = 0;
    if (strlen(title) < MIN_TITLE || strlen(title) > MAX_TITLE) {
        printf("Invalid title length! Please try again.\n");
    } else {
        int titleExist = 0;
        for (int i = 0; i < TABLE_SIZE; i++) {
            book* currentBook = hashTable[i];
            while (currentBook != NULL) {
                if (strcmp(currentBook->title, title) == 0) {
                    titleExist = 1;
                    break;
                }
                currentBook = currentBook->next;
            }
            if (titleExist) break;
        }
        if (titleExist) {
            printf("The book title is already exist! Please try again.\n");
        } else {
            valid = 1;
        }
    }
}
    while (1) { 
    printf("Enter Author (Mr. / Mrs.): ");
    fgets(author, MAX_AUTHOR_LENGTH, stdin);
    author[strcspn(author, "\n")] = 0;
    if (strncmp(author, "Mr. ", 4) == 0 || strncmp(author, "Mrs. ", 5) == 0) {
        break;
    } else {
        printf("Invalid author name!\n");
    }
}

while (1) {
    printf("Enter ISBN [10-13 digits][Numeric]: ");
    fgets(isbn, MAX_ISBN_LENGTH, stdin); fflush(stdin);
    isbn[strcspn(isbn, "\n")] = 0;
    int valid = 1;
    for (int i = 0; i < strlen(isbn); i++) {
        if (!isdigit(isbn[i])) {
            valid = 0;
            break;
        }
    }
    if (valid && strlen(isbn) >= 10 && strlen(isbn) <= 13) {
        break;
    } else {
        printf("ISBN must be numeric and have a length of 10-13 digits!\n");
    }
}
    
    while (1) {
    printf("Enter Page Number[>=16]: ");
    scanf("%d", &pages);
    getchar();
    if (pages >= MIN_PAGES) {
        break;
    } else {
        printf("Invalid page number!\n");
    }
}
    
    // Generate Book ID
    bookCounter++;
    char bookId[30];
    sprintf(bookId, "B%05d-%s-%c%c", bookCounter, isbn, toupper(author[0]), toupper(title[0]));
    
    // Hashing
    int key = hashFunction(bookId);
    
    // Insert into hash table
    book* newBook = (book*)malloc(sizeof(book));
    strcpy(newBook->bookId, bookId);
    strcpy(newBook->title, title);
    strcpy(newBook->author, author);
    strcpy(newBook->isbn, isbn);
    newBook->pages = pages;
    newBook->next = hashTable[key];
    hashTable[key] = newBook;

    printf("Insert Success! %s\n", bookId);
}

void removeBook() {
    char bookId[30];
    printf("Enter Book ID to remove: ");
    fgets(bookId, 30, stdin);
    bookId[strcspn(bookId, "\n")] = 0;
    
    int key = hashFunction(bookId);
    book* temp = hashTable[key];
    book* prev = NULL;
    
    while (temp && strcmp(temp->bookId, bookId) != 0) {
        prev = temp;
        temp = temp->next;
    }
    
    if (!temp) {
        printf("Book not found!\n");
        return;
    }
    
    printf("Book Id: %s\nBook Title: %s\nBook Author: %s\nBook ISBN: %s\nPage Number: %d\n", 
           temp->bookId, temp->title, temp->author, temp->isbn, temp->pages);
    
    char confirm;
    printf("Are you sure you want to delete this book? [y/n]: ");
    scanf(" %c", &confirm);
    getchar();
    if (confirm != 'y' && confirm != 'Y') {
        printf("Deletion cancelled!\n");
        return;
    }
    
    if (!prev) {
        hashTable[key] = temp->next;
    } else {
        prev->next = temp->next;
    }
    free(temp);
    printf("Delete success!\n");
}


int main() {
    initializeHashTable();
    int choice;
    do {
        printf("\nBluejack Library\n");
        printf("1. View Book\n");
        printf("2. Insert Book\n");
        printf("3. Remove Book\n");
        printf("4. Exit\n");
        printf("Choose: ");
        scanf("%d", &choice);
        getchar(); // clear buffer

        switch (choice) {
            case 1: viewBooks(); break;
            case 2: insertBook(); break;
            case 3: removeBook(); break;
            case 4: printf("Exiting...\n"); break;
            default: printf("Invalid choice!\n");
        }
    } while (choice != 4);
    free(hashTable);
    return 0;
}
